import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // User profiles for textile business owners
  profiles: defineTable({
    userId: v.id("users"),
    shopName: v.string(),
    ownerName: v.string(),
    phone: v.string(),
    location: v.string(),
    businessType: v.union(
      v.literal("textile_shop"),
      v.literal("powerloom"),
      v.literal("wholesaler"),
      v.literal("retailer")
    ),
    gstNumber: v.optional(v.string()),
    language: v.union(v.literal("tamil"), v.literal("english")),
    isVerified: v.boolean(),
  })
    .index("by_user", ["userId"])
    .index("by_location", ["location"])
    .index("by_business_type", ["businessType"]),

  // Suppliers database
  suppliers: defineTable({
    supplierName: v.string(),
    contactPerson: v.string(),
    phone: v.string(),
    location: v.string(),
    distanceFromBargur: v.number(), // in km
    clothTypes: v.array(v.string()),
    specialization: v.string(),
    rating: v.number(),
    isVerified: v.boolean(),
    gstNumber: v.optional(v.string()),
  })
    .index("by_location", ["location"])
    .index("by_distance", ["distanceFromBargur"])
    .index("by_rating", ["rating"]),

  // Products/Cloth inventory
  products: defineTable({
    clothName: v.string(),
    fabricType: v.union(
      v.literal("cotton"),
      v.literal("polyester"),
      v.literal("silk"),
      v.literal("linen"),
      v.literal("blend")
    ),
    gsm: v.number(), // Grams per square meter
    yarnCount: v.string(),
    width: v.number(), // in inches
    basePricePerMeter: v.number(),
    gstPercent: v.number(),
    supplierId: v.id("suppliers"),
    category: v.string(),
    color: v.string(),
    pattern: v.string(),
    shrinkageRate: v.number(),
    careInstructions: v.string(),
    seasonalDemand: v.object({
      summer: v.number(),
      monsoon: v.number(),
      winter: v.number(),
    }),
  })
    .index("by_fabric_type", ["fabricType"])
    .index("by_supplier", ["supplierId"])
    .index("by_category", ["category"])
    .index("by_price", ["basePricePerMeter"]),

  // Customer invoices
  invoices: defineTable({
    userId: v.id("users"),
    invoiceNumber: v.string(),
    customerName: v.string(),
    customerPhone: v.optional(v.string()),
    items: v.array(v.object({
      productId: v.id("products"),
      clothName: v.string(),
      quantity: v.number(), // in meters
      pricePerMeter: v.number(),
      totalPrice: v.number(),
    })),
    subtotal: v.number(),
    gstAmount: v.number(),
    totalAmount: v.number(),
    paymentStatus: v.union(
      v.literal("paid"),
      v.literal("pending"),
      v.literal("partial")
    ),
    paymentMethod: v.union(
      v.literal("cash"),
      v.literal("upi"),
      v.literal("card"),
      v.literal("credit")
    ),
    notes: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_invoice_number", ["invoiceNumber"])
    .index("by_payment_status", ["paymentStatus"])
    .index("by_creation_time", ["_creationTime"]),

  // AI Chat conversations
  conversations: defineTable({
    userId: v.id("users"),
    messages: v.array(v.object({
      role: v.union(v.literal("user"), v.literal("assistant")),
      content: v.string(),
      timestamp: v.number(),
    })),
    topic: v.string(),
    language: v.union(v.literal("tamil"), v.literal("english")),
  })
    .index("by_user", ["userId"])
    .index("by_topic", ["topic"]),

  // Market prices tracking
  marketPrices: defineTable({
    clothType: v.string(),
    fabricType: v.string(),
    location: v.string(),
    pricePerMeter: v.number(),
    date: v.string(),
    source: v.string(),
    quality: v.union(v.literal("premium"), v.literal("standard"), v.literal("economy")),
  })
    .index("by_cloth_type", ["clothType"])
    .index("by_location", ["location"])
    .index("by_date", ["date"]),

  // Business analytics
  salesAnalytics: defineTable({
    userId: v.id("users"),
    month: v.string(), // YYYY-MM format
    totalSales: v.number(),
    totalProfit: v.number(),
    topSellingCloth: v.string(),
    customerCount: v.number(),
    averageOrderValue: v.number(),
    gstCollected: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_month", ["month"]),

  // Demand forecasts
  demandForecasts: defineTable({
    clothType: v.string(),
    month: v.string(),
    predictedDemand: v.number(),
    factors: v.array(v.string()), // festival, season, etc.
    confidence: v.number(),
    region: v.string(),
  })
    .index("by_cloth_type", ["clothType"])
    .index("by_month", ["month"])
    .index("by_region", ["region"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
