import { query, mutation, action } from "./_generated/server";
import { v } from "convex/values";

export const getMarketPrices = query({
  args: {
    clothType: v.optional(v.string()),
    location: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    let pricesQuery = ctx.db.query("marketPrices");

    if (args.clothType) {
      pricesQuery = pricesQuery.withIndex("by_cloth_type", (q) => 
        q.eq("clothType", args.clothType)
      );
    }

    if (args.location) {
      pricesQuery = pricesQuery.withIndex("by_location", (q) => 
        q.eq("location", args.location)
      );
    }

    const prices = await pricesQuery
      .order("desc")
      .take(50);

    return prices;
  },
});

export const addMarketPrice = mutation({
  args: {
    clothType: v.string(),
    fabricType: v.string(),
    location: v.string(),
    pricePerMeter: v.number(),
    quality: v.union(v.literal("premium"), v.literal("standard"), v.literal("economy")),
    source: v.string(),
  },
  handler: async (ctx, args) => {
    const today = new Date().toISOString().split('T')[0];
    
    return await ctx.db.insert("marketPrices", {
      ...args,
      date: today,
    });
  },
});

export const getLatestPrices = query({
  args: {},
  handler: async (ctx) => {
    const today = new Date().toISOString().split('T')[0];
    
    const latestPrices = await ctx.db
      .query("marketPrices")
      .withIndex("by_date", (q) => q.eq("date", today))
      .collect();

    // Group by cloth type and get average prices
    const pricesByType: Record<string, { 
      average: number; 
      count: number; 
      premium: number; 
      standard: number; 
      economy: number; 
    }> = {};

    latestPrices.forEach(price => {
      if (!pricesByType[price.clothType]) {
        pricesByType[price.clothType] = {
          average: 0,
          count: 0,
          premium: 0,
          standard: 0,
          economy: 0,
        };
      }
      
      pricesByType[price.clothType][price.quality] = price.pricePerMeter;
      pricesByType[price.clothType].count++;
    });

    // Calculate averages
    Object.keys(pricesByType).forEach(clothType => {
      const data = pricesByType[clothType];
      data.average = (data.premium + data.standard + data.economy) / 3;
    });

    return pricesByType;
  },
});

export const updateMarketPrices = action({
  args: {},
  handler: async (ctx) => {
    // Simulate market price updates with realistic Tamil Nadu textile prices
    const clothTypes = [
      { type: "Cotton Shirting", fabric: "cotton", basePrice: 120 },
      { type: "Cotton Saree", fabric: "cotton", basePrice: 180 },
      { type: "Silk Saree", fabric: "silk", basePrice: 800 },
      { type: "Polyester Suiting", fabric: "polyester", basePrice: 150 },
      { type: "Linen Fabric", fabric: "linen", basePrice: 220 },
      { type: "Cotton Dhoti", fabric: "cotton", basePrice: 90 },
      { type: "Silk Blouse", fabric: "silk", basePrice: 450 },
    ];

    const locations = ["Bargur", "Krishnagiri", "Hosur", "Dharmapuri", "Salem"];
    const qualities: Array<"premium" | "standard" | "economy"> = ["premium", "standard", "economy"];

    for (const cloth of clothTypes) {
      for (const location of locations) {
        for (const quality of qualities) {
          // Add price variation based on quality and location
          let priceMultiplier = 1;
          
          if (quality === "premium") priceMultiplier = 1.3;
          else if (quality === "economy") priceMultiplier = 0.8;
          
          // Location-based pricing (Bargur as base)
          if (location === "Salem") priceMultiplier *= 1.1;
          else if (location === "Hosur") priceMultiplier *= 1.05;
          
          // Add random market fluctuation (±10%)
          const fluctuation = 0.9 + Math.random() * 0.2;
          
          const finalPrice = Math.round(cloth.basePrice * priceMultiplier * fluctuation);

          await ctx.runMutation(api.marketData.addMarketPrice, {
            clothType: cloth.type,
            fabricType: cloth.fabric,
            location,
            pricePerMeter: finalPrice,
            quality,
            source: "Market Survey",
          });
        }
      }
    }

    return { success: true, message: "Market prices updated successfully" };
  },
});

export const getPriceComparison = query({
  args: {
    clothType: v.string(),
    userPrice: v.number(),
  },
  handler: async (ctx, args) => {
    const marketPrices = await ctx.db
      .query("marketPrices")
      .withIndex("by_cloth_type", (q) => q.eq("clothType", args.clothType))
      .collect();

    if (marketPrices.length === 0) {
      return {
        comparison: "no_data",
        message: "No market data available for this cloth type",
        suggestion: "Consider adding this as a new market entry",
      };
    }

    const avgPrice = marketPrices.reduce((sum, p) => sum + p.pricePerMeter, 0) / marketPrices.length;
    const minPrice = Math.min(...marketPrices.map(p => p.pricePerMeter));
    const maxPrice = Math.max(...marketPrices.map(p => p.pricePerMeter));

    let comparison: "competitive" | "high" | "low";
    let message: string;
    let suggestion: string;

    if (args.userPrice <= avgPrice * 0.9) {
      comparison = "competitive";
      message = `Your price is ${((avgPrice - args.userPrice) / avgPrice * 100).toFixed(1)}% below market average`;
      suggestion = "Great pricing! You're competitive in the market";
    } else if (args.userPrice >= avgPrice * 1.1) {
      comparison = "high";
      message = `Your price is ${((args.userPrice - avgPrice) / avgPrice * 100).toFixed(1)}% above market average`;
      suggestion = "Consider reducing price or highlighting premium quality";
    } else {
      comparison = "competitive";
      message = "Your price is close to market average";
      suggestion = "Good pricing strategy for steady sales";
    }

    return {
      comparison,
      message,
      suggestion,
      marketData: {
        average: Math.round(avgPrice),
        minimum: minPrice,
        maximum: maxPrice,
        sampleSize: marketPrices.length,
      },
    };
  },
});
