import { action } from "./_generated/server";
import { v } from "convex/values";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const chatWithTextileAI = action({
  args: {
    message: v.string(),
    language: v.union(v.literal("tamil"), v.literal("english")),
    userContext: v.optional(v.object({
      businessType: v.string(),
      location: v.string(),
      shopName: v.string(),
    })),
  },
  handler: async (ctx, args) => {
    const systemPrompt = args.language === "tamil" 
      ? `நீங்கள் பர்கூர் பகுதியின் ஒரு நிபுணத்துவ வாய்ந்த துணி வியாபார ஆலோசகர். தமிழ்நாட்டின் துணி வியாபாரம், GST, விலை நிர்ணயம், லாபம் கணக்கீடு, சப்ளையர்கள், மற்றும் சந்தை தகவல்களில் நிபுணர். எப்போதும் இந்திய ரூபாயில் (₹) விலைகளை கூறுங்கள். பர்கூர் மற்றும் சுற்றியுள்ள பகுதிகளின் துணி வியாபாரத்தில் மட்டுமே கவனம் செலுத்துங்கள்.`
      : `You are an expert textile business consultant for Bargur region, Tamil Nadu. You specialize in cloth business, GST calculations, pricing strategies, profit margins, suppliers, and market intelligence. Always provide prices in Indian Rupees (₹). Focus only on Bargur and surrounding areas textile ecosystem. Be practical and give actionable business advice.`;

    const contextInfo = args.userContext 
      ? `User Context: Business Type: ${args.userContext.businessType}, Location: ${args.userContext.location}, Shop: ${args.userContext.shopName}`
      : "";

    try {
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `${contextInfo}\n\nUser Question: ${args.message}` }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      });

      return {
        response: completion.choices[0].message.content || "Sorry, I couldn't process your request.",
        success: true,
      };
    } catch (error) {
      console.error("OpenAI API error:", error);
      return {
        response: args.language === "tamil" 
          ? "மன்னிக்கவும், தற்போது AI சேவை கிடைக்கவில்லை. பிறகு முயற்சிக்கவும்."
          : "Sorry, AI service is currently unavailable. Please try again later.",
        success: false,
      };
    }
  },
});

export const calculatePricing = action({
  args: {
    baseCost: v.number(),
    gstPercent: v.number(),
    targetMargin: v.number(),
    transportCost: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { baseCost, gstPercent, targetMargin, transportCost = 0 } = args;
    
    // Calculate wholesale price
    const totalCost = baseCost + transportCost;
    const wholesalePrice = totalCost * (1 + targetMargin / 100);
    
    // Calculate retail price with GST
    const gstAmount = wholesalePrice * (gstPercent / 100);
    const retailPrice = wholesalePrice + gstAmount;
    
    // Calculate competitive pricing (10% below market average)
    const competitivePrice = retailPrice * 0.9;
    
    return {
      baseCost,
      transportCost,
      wholesalePrice: Math.round(wholesalePrice * 100) / 100,
      gstAmount: Math.round(gstAmount * 100) / 100,
      retailPrice: Math.round(retailPrice * 100) / 100,
      competitivePrice: Math.round(competitivePrice * 100) / 100,
      profitMargin: targetMargin,
      totalProfit: Math.round((wholesalePrice - totalCost) * 100) / 100,
    };
  },
});

export const generateDemandForecast = action({
  args: {
    clothType: v.string(),
    currentMonth: v.string(),
    historicalData: v.optional(v.array(v.object({
      month: v.string(),
      sales: v.number(),
    }))),
  },
  handler: async (ctx, args) => {
    // Simple demand forecasting based on seasonal patterns
    const seasonalFactors = {
      cotton: {
        "01": 0.8, "02": 0.9, "03": 1.2, "04": 1.4, "05": 1.3, "06": 1.1,
        "07": 0.9, "08": 0.8, "09": 1.0, "10": 1.3, "11": 1.5, "12": 1.2
      },
      silk: {
        "01": 1.2, "02": 1.1, "03": 1.0, "04": 0.9, "05": 0.8, "06": 0.7,
        "07": 0.8, "08": 0.9, "09": 1.1, "10": 1.4, "11": 1.6, "12": 1.5
      },
      polyester: {
        "01": 1.0, "02": 1.0, "03": 1.1, "04": 1.2, "05": 1.1, "06": 1.0,
        "07": 0.9, "08": 0.9, "09": 1.0, "10": 1.1, "11": 1.2, "12": 1.1
      }
    };

    const month = args.currentMonth.split("-")[1];
    const clothType = args.clothType.toLowerCase();
    
    const baseFactor = seasonalFactors[clothType as keyof typeof seasonalFactors]?.[month] || 1.0;
    
    // Festival bonuses
    const festivalBonus = ["03", "04", "10", "11"].includes(month) ? 1.2 : 1.0;
    
    const demandMultiplier = baseFactor * festivalBonus;
    
    return {
      clothType: args.clothType,
      month: args.currentMonth,
      demandMultiplier,
      recommendation: demandMultiplier > 1.2 
        ? "High demand expected - stock up inventory"
        : demandMultiplier < 0.9 
        ? "Low demand period - focus on clearance"
        : "Normal demand - maintain regular stock",
      factors: [
        demandMultiplier > 1.2 ? "Peak season" : "Regular season",
        festivalBonus > 1.0 ? "Festival season" : "Non-festival period"
      ]
    };
  },
});
