import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const findNearbySuppliers = query({
  args: {
    clothType: v.optional(v.string()),
    maxDistance: v.optional(v.number()),
    minRating: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const { clothType, maxDistance = 50, minRating = 3.0 } = args;
    
    let suppliersQuery = ctx.db.query("suppliers")
      .withIndex("by_distance")
      .filter((q) => q.lte(q.field("distanceFromBargur"), maxDistance))
      .filter((q) => q.gte(q.field("rating"), minRating));

    const suppliers = await suppliersQuery.collect();
    
    // Filter by cloth type if specified
    const filteredSuppliers = clothType 
      ? suppliers.filter(supplier => 
          supplier.clothTypes.some(type => 
            type.toLowerCase().includes(clothType.toLowerCase())
          )
        )
      : suppliers;

    return filteredSuppliers.map(supplier => ({
      ...supplier,
      distanceText: `${supplier.distanceFromBargur} km from Bargur`,
      contactInfo: {
        phone: supplier.phone,
        whatsapp: `https://wa.me/91${supplier.phone.replace(/\D/g, '')}`,
      }
    }));
  },
});

export const addSupplier = mutation({
  args: {
    supplierName: v.string(),
    contactPerson: v.string(),
    phone: v.string(),
    location: v.string(),
    distanceFromBargur: v.number(),
    clothTypes: v.array(v.string()),
    specialization: v.string(),
    gstNumber: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    return await ctx.db.insert("suppliers", {
      ...args,
      rating: 4.0, // Default rating
      isVerified: false,
    });
  },
});

export const getSupplierProducts = query({
  args: {
    supplierId: v.id("suppliers"),
  },
  handler: async (ctx, args) => {
    const products = await ctx.db
      .query("products")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .collect();

    return products;
  },
});

export const searchSuppliers = query({
  args: {
    searchTerm: v.string(),
  },
  handler: async (ctx, args) => {
    const allSuppliers = await ctx.db.query("suppliers").collect();
    
    const searchResults = allSuppliers.filter(supplier => 
      supplier.supplierName.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      supplier.location.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      supplier.clothTypes.some(type => 
        type.toLowerCase().includes(args.searchTerm.toLowerCase())
      ) ||
      supplier.specialization.toLowerCase().includes(args.searchTerm.toLowerCase())
    );

    return searchResults;
  },
});
