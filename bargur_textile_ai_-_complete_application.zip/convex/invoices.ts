import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createInvoice = mutation({
  args: {
    customerName: v.string(),
    customerPhone: v.optional(v.string()),
    items: v.array(v.object({
      productId: v.id("products"),
      clothName: v.string(),
      quantity: v.number(),
      pricePerMeter: v.number(),
      totalPrice: v.number(),
    })),
    paymentMethod: v.union(
      v.literal("cash"),
      v.literal("upi"),
      v.literal("card"),
      v.literal("credit")
    ),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    // Calculate totals
    const subtotal = args.items.reduce((sum, item) => sum + item.totalPrice, 0);
    
    // Calculate GST (assuming 12% for textiles)
    const gstAmount = subtotal * 0.12;
    const totalAmount = subtotal + gstAmount;

    // Generate invoice number
    const invoiceCount = await ctx.db.query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    
    const invoiceNumber = `BTA-${Date.now()}-${invoiceCount.length + 1}`;

    return await ctx.db.insert("invoices", {
      userId,
      invoiceNumber,
      customerName: args.customerName,
      customerPhone: args.customerPhone,
      items: args.items,
      subtotal,
      gstAmount,
      totalAmount,
      paymentStatus: "paid",
      paymentMethod: args.paymentMethod,
      notes: args.notes,
    });
  },
});

export const getUserInvoices = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(args.limit || 50);

    return invoices;
  },
});

export const getInvoiceById = query({
  args: {
    invoiceId: v.id("invoices"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const invoice = await ctx.db.get(args.invoiceId);
    
    if (!invoice || invoice.userId !== userId) {
      throw new Error("Invoice not found or access denied");
    }

    return invoice;
  },
});

export const updatePaymentStatus = mutation({
  args: {
    invoiceId: v.id("invoices"),
    paymentStatus: v.union(
      v.literal("paid"),
      v.literal("pending"),
      v.literal("partial")
    ),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const invoice = await ctx.db.get(args.invoiceId);
    
    if (!invoice || invoice.userId !== userId) {
      throw new Error("Invoice not found or access denied");
    }

    await ctx.db.patch(args.invoiceId, {
      paymentStatus: args.paymentStatus,
    });

    return { success: true };
  },
});

export const getSalesAnalytics = query({
  args: {
    startDate: v.optional(v.string()),
    endDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const invoices = await ctx.db
      .query("invoices")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    // Filter by date range if provided
    let filteredInvoices = invoices;
    if (args.startDate || args.endDate) {
      filteredInvoices = invoices.filter(invoice => {
        const invoiceDate = new Date(invoice._creationTime).toISOString().split('T')[0];
        if (args.startDate && invoiceDate < args.startDate) return false;
        if (args.endDate && invoiceDate > args.endDate) return false;
        return true;
      });
    }

    const totalSales = filteredInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const totalGST = filteredInvoices.reduce((sum, inv) => sum + inv.gstAmount, 0);
    const totalInvoices = filteredInvoices.length;
    const averageOrderValue = totalInvoices > 0 ? totalSales / totalInvoices : 0;

    // Top selling items
    const itemSales: Record<string, { quantity: number; revenue: number }> = {};
    filteredInvoices.forEach(invoice => {
      invoice.items.forEach(item => {
        if (!itemSales[item.clothName]) {
          itemSales[item.clothName] = { quantity: 0, revenue: 0 };
        }
        itemSales[item.clothName].quantity += item.quantity;
        itemSales[item.clothName].revenue += item.totalPrice;
      });
    });

    const topSellingItems = Object.entries(itemSales)
      .sort(([,a], [,b]) => b.revenue - a.revenue)
      .slice(0, 5)
      .map(([name, data]) => ({ name, ...data }));

    return {
      totalSales,
      totalGST,
      totalInvoices,
      averageOrderValue,
      topSellingItems,
      period: {
        startDate: args.startDate,
        endDate: args.endDate,
      }
    };
  },
});
