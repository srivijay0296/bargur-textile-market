import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createProfile = mutation({
  args: {
    shopName: v.string(),
    ownerName: v.string(),
    phone: v.string(),
    location: v.string(),
    businessType: v.union(
      v.literal("textile_shop"),
      v.literal("powerloom"),
      v.literal("wholesaler"),
      v.literal("retailer")
    ),
    gstNumber: v.optional(v.string()),
    language: v.union(v.literal("tamil"), v.literal("english")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    // Check if profile already exists
    const existingProfile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (existingProfile) {
      throw new Error("Profile already exists");
    }

    return await ctx.db.insert("profiles", {
      userId,
      ...args,
      isVerified: false,
    });
  },
});

export const getUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return profile;
  },
});

export const updateProfile = mutation({
  args: {
    shopName: v.optional(v.string()),
    ownerName: v.optional(v.string()),
    phone: v.optional(v.string()),
    location: v.optional(v.string()),
    businessType: v.optional(v.union(
      v.literal("textile_shop"),
      v.literal("powerloom"),
      v.literal("wholesaler"),
      v.literal("retailer")
    )),
    gstNumber: v.optional(v.string()),
    language: v.optional(v.union(v.literal("tamil"), v.literal("english"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required");
    }

    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!profile) {
      throw new Error("Profile not found");
    }

    // Filter out undefined values
    const updates = Object.fromEntries(
      Object.entries(args).filter(([_, value]) => value !== undefined)
    );

    await ctx.db.patch(profile._id, updates);
    return { success: true };
  },
});
