import { query, mutation, action } from "./_generated/server";
import { v } from "convex/values";

export const generateSeasonalForecast = action({
  args: {
    clothType: v.string(),
    region: v.string(),
  },
  handler: async (ctx, args) => {
    const currentMonth = new Date().getMonth() + 1;
    const currentYear = new Date().getFullYear();
    
    // Tamil Nadu seasonal patterns for textiles
    const seasonalFactors = {
      cotton: {
        1: 0.8,  // January - Post-winter, low demand
        2: 0.9,  // February - Pre-summer preparation
        3: 1.2,  // March - Summer season starts
        4: 1.4,  // April - Peak summer, high demand
        5: 1.3,  // May - Continued summer demand
        6: 1.1,  // June - Monsoon preparation
        7: 0.9,  // July - Monsoon season
        8: 0.8,  // August - Continued monsoon
        9: 1.0,  // September - Post-monsoon
        10: 1.3, // October - Festival season (Diwali prep)
        11: 1.5, // November - Peak festival season
        12: 1.2, // December - Wedding season
      },
      silk: {
        1: 1.2,  // January - Wedding season
        2: 1.1,  // February - Continued wedding season
        3: 1.0,  // March - Normal demand
        4: 0.9,  // April - Summer, less silk demand
        5: 0.8,  // May - Peak summer
        6: 0.7,  // June - Monsoon prep
        7: 0.8,  // July - Monsoon
        8: 0.9,  // August - Post-monsoon prep
        9: 1.1,  // September - Festival prep
        10: 1.4, // October - Diwali season
        11: 1.6, // November - Peak festival/wedding
        12: 1.5, // December - Wedding season
      },
      polyester: {
        1: 1.0,  // January - Steady demand
        2: 1.0,  // February - Steady
        3: 1.1,  // March - School uniform season
        4: 1.2,  // April - Summer clothing
        5: 1.1,  // May - Continued demand
        6: 1.0,  // June - Normal
        7: 0.9,  // July - Monsoon low
        8: 0.9,  // August - Continued low
        9: 1.0,  // September - School reopening
        10: 1.1, // October - Festival season
        11: 1.2, // November - Peak season
        12: 1.1, // December - Year-end
      }
    };

    // Festival impact (Tamil Nadu specific)
    const festivals = {
      1: ["Pongal"], // January
      3: ["Holi"], // March
      4: ["Tamil New Year"], // April
      8: ["Varalakshmi Vratam"], // August
      9: ["Ganesh Chaturthi"], // September
      10: ["Dussehra", "Diwali prep"], // October
      11: ["Diwali", "Karthigai Deepam"], // November
      12: ["Wedding season peak"], // December
    };

    const clothTypeLower = args.clothType.toLowerCase();
    const baseFactors = seasonalFactors[clothTypeLower as keyof typeof seasonalFactors] || seasonalFactors.cotton;
    
    // Generate 6-month forecast
    const forecast = [];
    for (let i = 0; i < 6; i++) {
      const month = ((currentMonth + i - 1) % 12) + 1;
      const year = currentYear + Math.floor((currentMonth + i - 1) / 12);
      
      let demandMultiplier = baseFactors[month as keyof typeof baseFactors] || 1.0;
      
      // Festival bonus
      const monthFestivals = festivals[month as keyof typeof festivals] || [];
      if (monthFestivals.length > 0) {
        demandMultiplier *= 1.1; // 10% boost for festival months
      }
      
      // Regional adjustments for Bargur area
      if (args.region.toLowerCase().includes("bargur") || args.region.toLowerCase().includes("krishnagiri")) {
        demandMultiplier *= 1.05; // 5% boost for local region
      }
      
      // Add some randomness for market volatility
      const volatility = 0.95 + Math.random() * 0.1; // ±5% random variation
      demandMultiplier *= volatility;
      
      const confidence = demandMultiplier > 1.2 ? 0.85 : demandMultiplier < 0.9 ? 0.75 : 0.9;
      
      forecast.push({
        month: `${year}-${month.toString().padStart(2, '0')}`,
        demandIndex: Math.round(demandMultiplier * 100),
        confidence: Math.round(confidence * 100),
        factors: [
          demandMultiplier > 1.2 ? "High seasonal demand" : demandMultiplier < 0.9 ? "Low seasonal demand" : "Normal demand",
          ...monthFestivals.map(f => `Festival: ${f}`),
          args.region.toLowerCase().includes("bargur") ? "Local market advantage" : "Regional market"
        ].filter(Boolean),
        recommendation: demandMultiplier > 1.2 
          ? "Stock up inventory - High demand expected"
          : demandMultiplier < 0.9 
          ? "Focus on clearance - Low demand period"
          : "Maintain regular stock levels"
      });
    }

    // Store forecast in database
    for (const monthForecast of forecast) {
      await ctx.runMutation(api.demandForecast.saveForecast, {
        clothType: args.clothType,
        month: monthForecast.month,
        predictedDemand: monthForecast.demandIndex,
        factors: monthForecast.factors,
        confidence: monthForecast.confidence / 100,
        region: args.region,
      });
    }

    return {
      clothType: args.clothType,
      region: args.region,
      forecast,
      summary: {
        avgDemand: Math.round(forecast.reduce((sum, f) => sum + f.demandIndex, 0) / forecast.length),
        peakMonth: forecast.reduce((max, f) => f.demandIndex > max.demandIndex ? f : max),
        lowMonth: forecast.reduce((min, f) => f.demandIndex < min.demandIndex ? f : min),
      }
    };
  },
});

export const saveForecast = mutation({
  args: {
    clothType: v.string(),
    month: v.string(),
    predictedDemand: v.number(),
    factors: v.array(v.string()),
    confidence: v.number(),
    region: v.string(),
  },
  handler: async (ctx, args) => {
    // Check if forecast already exists for this month/cloth type/region
    const existing = await ctx.db
      .query("demandForecasts")
      .withIndex("by_cloth_type", (q) => q.eq("clothType", args.clothType))
      .filter((q) => q.eq(q.field("month"), args.month))
      .filter((q) => q.eq(q.field("region"), args.region))
      .first();

    if (existing) {
      // Update existing forecast
      await ctx.db.patch(existing._id, {
        predictedDemand: args.predictedDemand,
        factors: args.factors,
        confidence: args.confidence,
      });
      return existing._id;
    } else {
      // Create new forecast
      return await ctx.db.insert("demandForecasts", args);
    }
  },
});

export const getForecast = query({
  args: {
    clothType: v.optional(v.string()),
    region: v.optional(v.string()),
    months: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    let forecastQuery = ctx.db.query("demandForecasts");

    if (args.clothType) {
      forecastQuery = forecastQuery.withIndex("by_cloth_type", (q) => 
        q.eq("clothType", args.clothType)
      );
    }

    let forecasts = await forecastQuery
      .order("desc")
      .take(args.months || 6);

    // Filter by region if specified
    if (args.region) {
      forecasts = forecasts.filter(f => 
        f.region.toLowerCase().includes(args.region!.toLowerCase())
      );
    }

    return forecasts;
  },
});

export const getBusinessRecommendations = query({
  args: {
    region: v.string(),
  },
  handler: async (ctx, args) => {
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM format
    
    const forecasts = await ctx.db
      .query("demandForecasts")
      .withIndex("by_month", (q) => q.eq("month", currentMonth))
      .filter((q) => q.eq(q.field("region"), args.region))
      .collect();

    const recommendations = [];

    // High demand products
    const highDemandProducts = forecasts.filter(f => f.predictedDemand > 120);
    if (highDemandProducts.length > 0) {
      recommendations.push({
        type: "stock_up",
        priority: "high",
        title: "Stock Up Recommendations",
        description: `High demand expected for: ${highDemandProducts.map(p => p.clothType).join(", ")}`,
        action: "Increase inventory by 20-30%",
        products: highDemandProducts.map(p => p.clothType),
      });
    }

    // Low demand products
    const lowDemandProducts = forecasts.filter(f => f.predictedDemand < 80);
    if (lowDemandProducts.length > 0) {
      recommendations.push({
        type: "clearance",
        priority: "medium",
        title: "Clearance Sale Opportunity",
        description: `Low demand period for: ${lowDemandProducts.map(p => p.clothType).join(", ")}`,
        action: "Offer 10-15% discount to clear inventory",
        products: lowDemandProducts.map(p => p.clothType),
      });
    }

    // Festival-based recommendations
    const festivalProducts = forecasts.filter(f => 
      f.factors.some(factor => factor.toLowerCase().includes("festival"))
    );
    if (festivalProducts.length > 0) {
      recommendations.push({
        type: "festival",
        priority: "high",
        title: "Festival Season Preparation",
        description: "Festival demand boost expected",
        action: "Prepare special festival collections and pricing",
        products: festivalProducts.map(p => p.clothType),
      });
    }

    // Seasonal recommendations
    const month = new Date().getMonth() + 1;
    if (month >= 3 && month <= 5) { // Summer season
      recommendations.push({
        type: "seasonal",
        priority: "medium",
        title: "Summer Collection Focus",
        description: "Summer season - focus on light, breathable fabrics",
        action: "Promote cotton and linen products",
        products: ["Cotton Shirting", "Linen Fabric", "Cotton Saree"],
      });
    } else if (month >= 10 && month <= 12) { // Festival/Wedding season
      recommendations.push({
        type: "seasonal",
        priority: "high",
        title: "Festival & Wedding Season",
        description: "Peak season for premium fabrics",
        action: "Stock premium silk and designer fabrics",
        products: ["Silk Saree", "Silk Blouse", "Designer Fabrics"],
      });
    }

    return recommendations;
  },
});
