import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getProducts = query({
  args: {
    fabricType: v.optional(v.string()),
    category: v.optional(v.string()),
    maxPrice: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    let productsQuery = ctx.db.query("products");

    if (args.fabricType) {
      productsQuery = productsQuery.withIndex("by_fabric_type", (q) => 
        q.eq("fabricType", args.fabricType as any)
      );
    }

    let products = await productsQuery.collect();

    // Apply additional filters
    if (args.category) {
      products = products.filter(p => 
        p.category.toLowerCase().includes(args.category!.toLowerCase())
      );
    }

    if (args.maxPrice) {
      products = products.filter(p => p.basePricePerMeter <= args.maxPrice!);
    }

    // Enrich with supplier info
    const enrichedProducts = await Promise.all(
      products.map(async (product) => {
        const supplier = await ctx.db.get(product.supplierId);
        return {
          ...product,
          supplier: supplier ? {
            name: supplier.supplierName,
            location: supplier.location,
            rating: supplier.rating,
          } : null,
          finalPrice: product.basePricePerMeter * (1 + product.gstPercent / 100),
        };
      })
    );

    return enrichedProducts;
  },
});

export const getProductById = query({
  args: {
    productId: v.id("products"),
  },
  handler: async (ctx, args) => {
    const product = await ctx.db.get(args.productId);
    if (!product) return null;

    const supplier = await ctx.db.get(product.supplierId);
    
    return {
      ...product,
      supplier,
      finalPrice: product.basePricePerMeter * (1 + product.gstPercent / 100),
    };
  },
});

export const addProduct = mutation({
  args: {
    clothName: v.string(),
    fabricType: v.union(
      v.literal("cotton"),
      v.literal("polyester"),
      v.literal("silk"),
      v.literal("linen"),
      v.literal("blend")
    ),
    gsm: v.number(),
    yarnCount: v.string(),
    width: v.number(),
    basePricePerMeter: v.number(),
    gstPercent: v.number(),
    supplierId: v.id("suppliers"),
    category: v.string(),
    color: v.string(),
    pattern: v.string(),
    shrinkageRate: v.number(),
    careInstructions: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("products", {
      ...args,
      seasonalDemand: {
        summer: 1.0,
        monsoon: 0.8,
        winter: 1.2,
      },
    });
  },
});

export const searchProducts = query({
  args: {
    searchTerm: v.string(),
  },
  handler: async (ctx, args) => {
    const allProducts = await ctx.db.query("products").collect();
    
    const searchResults = allProducts.filter(product => 
      product.clothName.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      product.fabricType.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      product.color.toLowerCase().includes(args.searchTerm.toLowerCase()) ||
      product.pattern.toLowerCase().includes(args.searchTerm.toLowerCase())
    );

    return searchResults;
  },
});

export const getFabricGuide = query({
  args: {
    fabricType: v.string(),
  },
  handler: async (ctx, args) => {
    const fabricGuides = {
      cotton: {
        description: "Natural fiber, breathable, comfortable",
        gsmRange: "120-200 GSM",
        yarnCounts: ["20s", "30s", "40s", "60s"],
        shrinkageRate: "3-5%",
        careInstructions: "Machine wash cold, tumble dry low",
        qualityChecks: [
          "Feel the texture - should be soft and smooth",
          "Check for consistent weave",
          "Look for natural cotton smell",
          "Test absorbency with water drop"
        ],
        priceRange: "₹80-250 per meter",
        bestFor: "Shirts, casual wear, home textiles"
      },
      polyester: {
        description: "Synthetic fiber, durable, wrinkle-resistant",
        gsmRange: "100-180 GSM",
        yarnCounts: ["75D", "100D", "150D"],
        shrinkageRate: "1-2%",
        careInstructions: "Machine wash warm, hang dry",
        qualityChecks: [
          "Check for uniform color",
          "Test for static electricity",
          "Verify wrinkle resistance",
          "Check fabric strength"
        ],
        priceRange: "₹60-180 per meter",
        bestFor: "Sportswear, formal wear, curtains"
      },
      silk: {
        description: "Natural protein fiber, luxurious, lustrous",
        gsmRange: "80-140 GSM",
        yarnCounts: ["20/22D", "30/32D"],
        shrinkageRate: "2-3%",
        careInstructions: "Dry clean only or gentle hand wash",
        qualityChecks: [
          "Check for natural luster",
          "Feel for smoothness",
          "Test with burn test (smells like hair)",
          "Look for consistent weave"
        ],
        priceRange: "₹300-1500 per meter",
        bestFor: "Sarees, formal wear, luxury items"
      }
    };

    return fabricGuides[args.fabricType.toLowerCase() as keyof typeof fabricGuides] || null;
  },
});
