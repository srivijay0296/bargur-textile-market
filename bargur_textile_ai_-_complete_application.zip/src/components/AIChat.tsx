import { useState, useRef, useEffect } from "react";
import { useAction } from "convex/react";
import { api } from "../../convex/_generated/api";

interface AIChatProps {
  profile: any;
}

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}

export function AIChat({ profile }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: profile.language === "tamil" 
        ? `வணக்கம் ${profile.ownerName}! நான் உங்கள் துணி வியாபார AI உதவியாளர். விலை நிர்ணயம், சப்ளையர்கள், GST கணக்கீடு, அல்லது வேறு ஏதேனும் துணி வியாபார கேள்விகள் இருந்தால் கேளுங்கள்.`
        : `Hello ${profile.ownerName}! I'm your textile business AI assistant. Ask me anything about pricing, suppliers, GST calculations, or any textile business questions.`,
      timestamp: Date.now(),
    },
  ]);
  
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const chatWithAI = useAction(api.textileAI.chatWithTextileAI);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isLoading) return;

    const userMessage: Message = {
      role: "user",
      content: inputMessage,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);

    try {
      const response = await chatWithAI({
        message: inputMessage,
        language: profile.language,
        userContext: {
          businessType: profile.businessType,
          location: profile.location,
          shopName: profile.shopName,
        },
      });

      const assistantMessage: Message = {
        role: "assistant",
        content: response.response,
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Chat error:", error);
      const errorMessage: Message = {
        role: "assistant",
        content: profile.language === "tamil"
          ? "மன்னிக்கவும், ஏதோ பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்."
          : "Sorry, something went wrong. Please try again.",
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickQuestions = profile.language === "tamil" ? [
    "இன்றைய காட்டன் விலை என்ன?",
    "GST கணக்கீடு எப்படி செய்வது?",
    "பர்கூர் அருகில் உள்ள சப்ளையர்கள்",
    "பண்டிகை காலத்தில் எந்த துணி நன்றாக விற்கும்?",
  ] : [
    "What's today's cotton price?",
    "How to calculate GST for textiles?",
    "Best suppliers near Bargur",
    "Which fabric sells well during festivals?",
  ];

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200">
        <h3 className="font-semibold text-blue-900 mb-2">
          {profile.language === "tamil" ? "AI துணி வியாபார உதவியாளர்" : "AI Textile Business Assistant"}
        </h3>
        <p className="text-blue-700 text-sm">
          {profile.language === "tamil" 
            ? "விலை நிர்ணயம், சப்ளையர்கள், GST, மற்றும் வியாபார ஆலோசனைகளுக்கு கேளுங்கள்"
            : "Ask about pricing, suppliers, GST, and business advice"
          }
        </p>
      </div>

      {/* Quick Questions */}
      <div className="grid grid-cols-2 gap-2">
        {quickQuestions.map((question, index) => (
          <button
            key={index}
            onClick={() => setInputMessage(question)}
            className="text-left p-3 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200 text-sm transition-colors"
          >
            {question}
          </button>
        ))}
      </div>

      {/* Chat Messages */}
      <div className="bg-gray-50 rounded-lg p-4 h-96 overflow-y-auto space-y-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                message.role === "user"
                  ? "bg-amber-500 text-white"
                  : "bg-white text-gray-800 border border-gray-200"
              }`}
            >
              <p className="text-sm whitespace-pre-wrap">{message.content}</p>
              <p className={`text-xs mt-1 ${
                message.role === "user" ? "text-amber-100" : "text-gray-500"
              }`}>
                {new Date(message.timestamp).toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white text-gray-800 border border-gray-200 px-4 py-2 rounded-lg">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form */}
      <form onSubmit={handleSendMessage} className="flex space-x-2">
        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          placeholder={profile.language === "tamil" ? "உங்கள் கேள்வியை இங்கே டைப் செய்யுங்கள்..." : "Type your question here..."}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !inputMessage.trim()}
          className="px-6 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {profile.language === "tamil" ? "அனுப்பு" : "Send"}
        </button>
      </form>
    </div>
  );
}
