import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function ProductCatalog() {
  const [filters, setFilters] = useState({
    fabricType: "",
    category: "",
    maxPrice: "",
  });

  const [selectedFabric, setSelectedFabric] = useState("");

  const products = useQuery(api.products.getProducts, {
    fabricType: filters.fabricType || undefined,
    category: filters.category || undefined,
    maxPrice: filters.maxPrice ? parseFloat(filters.maxPrice) : undefined,
  });

  const fabricGuide = useQuery(api.products.getFabricGuide, {
    fabricType: selectedFabric,
  }, selectedFabric ? undefined : "skip");

  const fabricTypes = ["cotton", "polyester", "silk", "linen", "blend"];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg p-4 border border-indigo-200">
        <h3 className="font-semibold text-indigo-900 mb-2">Product Catalog & Fabric Guide</h3>
        <p className="text-indigo-700 text-sm">
          Browse textile products and learn about fabric properties, quality checks, and pricing
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Filters */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h4 className="font-medium text-gray-900 mb-4">Filters</h4>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fabric Type
              </label>
              <select
                value={filters.fabricType}
                onChange={(e) => setFilters({ ...filters, fabricType: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              >
                <option value="">All Types</option>
                {fabricTypes.map(type => (
                  <option key={type} value={type}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category
              </label>
              <input
                type="text"
                value={filters.category}
                onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                placeholder="e.g., shirting, suiting"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Max Price (₹/meter)
              </label>
              <input
                type="number"
                value={filters.maxPrice}
                onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                placeholder="Enter max price"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              />
            </div>
          </div>

          {/* Fabric Guide Selector */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <h5 className="font-medium text-gray-900 mb-2">Fabric Guide</h5>
            <select
              value={selectedFabric}
              onChange={(e) => setSelectedFabric(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              <option value="">Select fabric to learn</option>
              {fabricTypes.map(type => (
                <option key={type} value={type}>
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Products List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {products?.map((product) => (
              <div key={product._id} className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h4 className="font-semibold text-gray-900">{product.clothName}</h4>
                    <p className="text-sm text-gray-600 capitalize">{product.fabricType}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">₹{product.finalPrice}</div>
                    <div className="text-xs text-gray-500">per meter</div>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">GSM:</span>
                    <span className="font-medium">{product.gsm}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Width:</span>
                    <span className="font-medium">{product.width}"</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Yarn Count:</span>
                    <span className="font-medium">{product.yarnCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Shrinkage:</span>
                    <span className="font-medium">{product.shrinkageRate}%</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-3">
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                    {product.color}
                  </span>
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">
                    {product.pattern}
                  </span>
                  <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                    {product.category}
                  </span>
                </div>

                {product.supplier && (
                  <div className="text-xs text-gray-500 border-t border-gray-100 pt-2">
                    Supplier: {product.supplier.name} • {product.supplier.location}
                    <span className="ml-2">⭐ {product.supplier.rating}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {products?.length === 0 && (
            <div className="text-center py-8">
              <div className="text-gray-400 text-4xl mb-2">📦</div>
              <p className="text-gray-600">No products found</p>
              <p className="text-sm text-gray-500 mt-1">Try adjusting your filters</p>
            </div>
          )}
        </div>
      </div>

      {/* Fabric Guide */}
      {fabricGuide && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">
            {selectedFabric.charAt(0).toUpperCase() + selectedFabric.slice(1)} Fabric Guide
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <h5 className="font-medium text-gray-700 mb-2">Description</h5>
                <p className="text-sm text-gray-600">{fabricGuide.description}</p>
              </div>

              <div>
                <h5 className="font-medium text-gray-700 mb-2">Specifications</h5>
                <div className="space-y-1 text-sm">
                  <div><strong>GSM Range:</strong> {fabricGuide.gsmRange}</div>
                  <div><strong>Yarn Counts:</strong> {fabricGuide.yarnCounts.join(", ")}</div>
                  <div><strong>Shrinkage Rate:</strong> {fabricGuide.shrinkageRate}</div>
                  <div><strong>Price Range:</strong> {fabricGuide.priceRange}</div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h5 className="font-medium text-gray-700 mb-2">Quality Checks</h5>
                <ul className="text-sm text-gray-600 space-y-1">
                  {fabricGuide.qualityChecks.map((check, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-green-500 mr-2">•</span>
                      {check}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h5 className="font-medium text-gray-700 mb-2">Care Instructions</h5>
                <p className="text-sm text-gray-600">{fabricGuide.careInstructions}</p>
              </div>

              <div>
                <h5 className="font-medium text-gray-700 mb-2">Best For</h5>
                <p className="text-sm text-gray-600">{fabricGuide.bestFor}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
