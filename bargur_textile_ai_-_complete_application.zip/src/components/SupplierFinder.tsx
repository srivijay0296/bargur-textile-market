import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function SupplierFinder() {
  const [filters, setFilters] = useState({
    clothType: "",
    maxDistance: 50,
    minRating: 3.0,
  });

  const suppliers = useQuery(api.suppliers.findNearbySuppliers, {
    clothType: filters.clothType || undefined,
    maxDistance: filters.maxDistance,
    minRating: filters.minRating,
  });

  const handleWhatsAppContact = (phone: string, supplierName: string) => {
    const message = encodeURIComponent(`Hello ${supplierName}, I found your contact through Bargur Textile AI. I'm interested in your textile products. Can we discuss business?`);
    window.open(`https://wa.me/91${phone.replace(/\D/g, '')}?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-200">
        <h3 className="font-semibold text-green-900 mb-2">Local Supplier Network</h3>
        <p className="text-green-700 text-sm">
          Find verified textile suppliers within 50km of Bargur with competitive rates
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg p-4 border border-gray-200">
        <h4 className="font-medium text-gray-900 mb-4">Filter Suppliers</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cloth Type
            </label>
            <input
              type="text"
              value={filters.clothType}
              onChange={(e) => setFilters({ ...filters, clothType: e.target.value })}
              placeholder="e.g., cotton, silk, polyester"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Max Distance (km)
            </label>
            <select
              value={filters.maxDistance}
              onChange={(e) => setFilters({ ...filters, maxDistance: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              <option value={25}>Within 25 km</option>
              <option value={50}>Within 50 km</option>
              <option value={100}>Within 100 km</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Minimum Rating
            </label>
            <select
              value={filters.minRating}
              onChange={(e) => setFilters({ ...filters, minRating: Number(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              <option value={3.0}>3.0+ Stars</option>
              <option value={3.5}>3.5+ Stars</option>
              <option value={4.0}>4.0+ Stars</option>
              <option value={4.5}>4.5+ Stars</option>
            </select>
          </div>
        </div>
      </div>

      {/* Suppliers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {suppliers?.map((supplier) => (
          <div key={supplier._id} className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-semibold text-gray-900">{supplier.supplierName}</h4>
                <p className="text-sm text-gray-600">{supplier.contactPerson}</p>
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-yellow-400">⭐</span>
                <span className="text-sm font-medium">{supplier.rating}</span>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center text-sm text-gray-600">
                <span className="w-4 h-4 mr-2">📍</span>
                {supplier.location} ({supplier.distanceText})
              </div>
              
              <div className="flex items-center text-sm text-gray-600">
                <span className="w-4 h-4 mr-2">🏭</span>
                {supplier.specialization}
              </div>

              <div className="flex flex-wrap gap-1 mt-2">
                {supplier.clothTypes.slice(0, 3).map((type, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-amber-100 text-amber-800 text-xs rounded-full"
                  >
                    {type}
                  </span>
                ))}
                {supplier.clothTypes.length > 3 && (
                  <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                    +{supplier.clothTypes.length - 3} more
                  </span>
                )}
              </div>
            </div>

            <div className="flex space-x-2">
              <button
                onClick={() => handleWhatsAppContact(supplier.phone, supplier.supplierName)}
                className="flex-1 bg-green-500 text-white py-2 px-3 rounded-lg text-sm font-medium hover:bg-green-600 transition-colors"
              >
                WhatsApp
              </button>
              <a
                href={`tel:${supplier.phone}`}
                className="flex-1 bg-blue-500 text-white py-2 px-3 rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors text-center"
              >
                Call
              </a>
            </div>

            {supplier.isVerified && (
              <div className="mt-2 flex items-center text-xs text-green-600">
                <span className="w-3 h-3 mr-1">✓</span>
                Verified Supplier
              </div>
            )}
          </div>
        ))}
      </div>

      {suppliers?.length === 0 && (
        <div className="text-center py-8">
          <div className="text-gray-400 text-4xl mb-2">🔍</div>
          <p className="text-gray-600">No suppliers found matching your criteria</p>
          <p className="text-sm text-gray-500 mt-1">Try adjusting your filters</p>
        </div>
      )}
    </div>
  );
}
