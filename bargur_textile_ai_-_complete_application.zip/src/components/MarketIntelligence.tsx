import { useState } from "react";
import { useQuery, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function MarketIntelligence() {
  const [selectedCloth, setSelectedCloth] = useState("Cotton Shirting");
  const [userPrice, setUserPrice] = useState("");
  const [location, setLocation] = useState("Bargur");

  const marketPrices = useQuery(api.marketData.getMarketPrices, {
    clothType: selectedCloth,
    location: location,
  });

  const latestPrices = useQuery(api.marketData.getLatestPrices, {});
  
  const priceComparison = useQuery(api.marketData.getPriceComparison, 
    userPrice ? {
      clothType: selectedCloth,
      userPrice: parseFloat(userPrice),
    } : "skip"
  );

  const updateMarketPrices = useAction(api.marketData.updateMarketPrices);

  const clothTypes = [
    "Cotton Shirting",
    "Cotton Saree", 
    "Silk Saree",
    "Polyester Suiting",
    "Linen Fabric",
    "Cotton Dhoti",
    "Silk Blouse"
  ];

  const locations = [
    "Bargur",
    "Krishnagiri", 
    "Hosur",
    "Dharmapuri",
    "Salem"
  ];

  const handleUpdatePrices = async () => {
    try {
      await updateMarketPrices({});
      toast.success("Market prices updated successfully!");
    } catch (error) {
      toast.error("Failed to update market prices");
      console.error(error);
    }
  };

  const getComparisonColor = (comparison: string) => {
    switch (comparison) {
      case "competitive": return "text-green-600 bg-green-50";
      case "high": return "text-red-600 bg-red-50";
      case "low": return "text-blue-600 bg-blue-50";
      default: return "text-gray-600 bg-gray-50";
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-lg p-4 border border-teal-200">
        <h3 className="font-semibold text-teal-900 mb-2">Market Intelligence Dashboard</h3>
        <p className="text-teal-700 text-sm">
          Real-time market prices, competitive analysis, and pricing recommendations for Tamil Nadu textile market
        </p>
      </div>

      {/* Price Comparison Tool */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Price Comparison Tool</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cloth Type
            </label>
            <select
              value={selectedCloth}
              onChange={(e) => setSelectedCloth(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              {clothTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Your Price (₹/meter)
            </label>
            <input
              type="number"
              value={userPrice}
              onChange={(e) => setUserPrice(e.target.value)}
              placeholder="Enter your price"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Location
            </label>
            <select
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              {locations.map(loc => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleUpdatePrices}
              className="w-full bg-teal-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-teal-600 transition-colors"
            >
              Update Prices
            </button>
          </div>
        </div>

        {/* Price Comparison Results */}
        {priceComparison && (
          <div className="bg-gray-50 rounded-lg p-4">
            <div className={`inline-block px-3 py-1 rounded-full text-sm font-medium mb-3 ${getComparisonColor(priceComparison.comparison)}`}>
              {priceComparison.comparison === "competitive" && "✅ Competitive Price"}
              {priceComparison.comparison === "high" && "⚠️ Above Market"}
              {priceComparison.comparison === "low" && "💰 Below Market"}
            </div>
            
            <p className="text-gray-700 mb-2">{priceComparison.message}</p>
            <p className="text-sm text-gray-600 mb-4">{priceComparison.suggestion}</p>
            
            {priceComparison.marketData && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-900">₹{priceComparison.marketData.average}</div>
                  <div className="text-xs text-gray-500">Market Average</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-green-600">₹{priceComparison.marketData.minimum}</div>
                  <div className="text-xs text-gray-500">Minimum Price</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-red-600">₹{priceComparison.marketData.maximum}</div>
                  <div className="text-xs text-gray-500">Maximum Price</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-600">{priceComparison.marketData.sampleSize}</div>
                  <div className="text-xs text-gray-500">Data Points</div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Latest Market Prices */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Today's Market Prices</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {latestPrices && Object.entries(latestPrices).map(([clothType, data]) => (
            <div key={clothType} className="border border-gray-200 rounded-lg p-4">
              <h5 className="font-medium text-gray-900 mb-3">{clothType}</h5>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Premium:</span>
                  <span className="font-medium text-purple-600">₹{data.premium || 'N/A'}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Standard:</span>
                  <span className="font-medium text-blue-600">₹{data.standard || 'N/A'}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Economy:</span>
                  <span className="font-medium text-green-600">₹{data.economy || 'N/A'}</span>
                </div>
                <div className="flex justify-between items-center border-t border-gray-200 pt-2">
                  <span className="text-sm font-medium text-gray-700">Average:</span>
                  <span className="font-bold text-gray-900">₹{Math.round(data.average) || 'N/A'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Historical Price Trends */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Price History: {selectedCloth} in {location}</h4>
        
        <div className="space-y-3">
          {marketPrices?.slice(0, 10).map((price, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className={`w-3 h-3 rounded-full ${
                  price.quality === "premium" ? "bg-purple-500" :
                  price.quality === "standard" ? "bg-blue-500" : "bg-green-500"
                }`}></div>
                <div>
                  <div className="font-medium text-gray-900">{price.fabricType}</div>
                  <div className="text-sm text-gray-600">{price.quality} • {price.source}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-gray-900">₹{price.pricePerMeter}</div>
                <div className="text-xs text-gray-500">{price.date}</div>
              </div>
            </div>
          ))}
        </div>

        {(!marketPrices || marketPrices.length === 0) && (
          <div className="text-center py-8">
            <div className="text-gray-400 text-4xl mb-2">📊</div>
            <p className="text-gray-600">No price history available</p>
            <p className="text-sm text-gray-500 mt-1">Update market prices to see trends</p>
          </div>
        )}
      </div>

      {/* Market Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Market Insights</h4>
          
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h5 className="font-medium text-blue-900 mb-2">💡 Pricing Strategy</h5>
              <p className="text-sm text-blue-700">
                Price your products 5-10% below market average for competitive advantage, 
                or match market price for premium positioning.
              </p>
            </div>

            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <h5 className="font-medium text-green-900 mb-2">📈 Market Trends</h5>
              <p className="text-sm text-green-700">
                Cotton prices are stable this season. Silk prices show upward trend due to 
                festival demand. Consider stocking accordingly.
              </p>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <h5 className="font-medium text-purple-900 mb-2">🎯 Negotiation Tips</h5>
              <p className="text-sm text-purple-700">
                Use market data to negotiate with suppliers. Show price comparisons 
                to get better rates and improve your margins.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Regional Price Variations</h4>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Bargur</div>
                <div className="text-sm text-gray-600">Base market</div>
              </div>
              <div className="text-green-600 font-medium">Base Price</div>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Krishnagiri</div>
                <div className="text-sm text-gray-600">District headquarters</div>
              </div>
              <div className="text-blue-600 font-medium">+2-3%</div>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Hosur</div>
                <div className="text-sm text-gray-600">Industrial hub</div>
              </div>
              <div className="text-orange-600 font-medium">+5-7%</div>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Salem</div>
                <div className="text-sm text-gray-600">Major textile center</div>
              </div>
              <div className="text-red-600 font-medium">+10-15%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
