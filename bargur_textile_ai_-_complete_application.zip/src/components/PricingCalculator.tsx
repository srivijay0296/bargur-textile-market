import { useState } from "react";
import { useAction } from "convex/react";
import { api } from "../../convex/_generated/api";

export function PricingCalculator() {
  const [inputs, setInputs] = useState({
    baseCost: "",
    gstPercent: "12",
    targetMargin: "25",
    transportCost: "",
  });

  const [result, setResult] = useState<any>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const calculatePricing = useAction(api.textileAI.calculatePricing);

  const handleCalculate = async () => {
    if (!inputs.baseCost) return;

    setIsCalculating(true);
    try {
      const pricing = await calculatePricing({
        baseCost: parseFloat(inputs.baseCost),
        gstPercent: parseFloat(inputs.gstPercent),
        targetMargin: parseFloat(inputs.targetMargin),
        transportCost: inputs.transportCost ? parseFloat(inputs.transportCost) : undefined,
      });
      setResult(pricing);
    } catch (error) {
      console.error("Pricing calculation error:", error);
    } finally {
      setIsCalculating(false);
    }
  };

  const gstSlabs = [
    { rate: "5%", description: "Cotton fiber, raw silk" },
    { rate: "12%", description: "Most textiles, fabrics" },
    { rate: "18%", description: "Synthetic textiles, branded items" },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-200">
        <h3 className="font-semibold text-purple-900 mb-2">Smart Pricing Calculator</h3>
        <p className="text-purple-700 text-sm">
          Calculate wholesale, retail, and competitive prices with GST for your textile products
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Pricing Inputs</h4>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Base Cost per Meter (₹) *
              </label>
              <input
                type="number"
                value={inputs.baseCost}
                onChange={(e) => setInputs({ ...inputs, baseCost: e.target.value })}
                placeholder="Enter base cost"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                GST Percentage (%)
              </label>
              <select
                value={inputs.gstPercent}
                onChange={(e) => setInputs({ ...inputs, gstPercent: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              >
                <option value="5">5% - Cotton fiber, raw silk</option>
                <option value="12">12% - Most textiles, fabrics</option>
                <option value="18">18% - Synthetic textiles</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Target Profit Margin (%)
              </label>
              <input
                type="number"
                value={inputs.targetMargin}
                onChange={(e) => setInputs({ ...inputs, targetMargin: e.target.value })}
                placeholder="Enter target margin"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Transport Cost per Meter (₹) - Optional
              </label>
              <input
                type="number"
                value={inputs.transportCost}
                onChange={(e) => setInputs({ ...inputs, transportCost: e.target.value })}
                placeholder="Enter transport cost"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              />
            </div>

            <button
              onClick={handleCalculate}
              disabled={!inputs.baseCost || isCalculating}
              className="w-full bg-amber-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-amber-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isCalculating ? "Calculating..." : "Calculate Pricing"}
            </button>
          </div>
        </div>

        {/* Results */}
        <div className="space-y-4">
          {result && (
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <h4 className="font-medium text-gray-900 mb-4">Pricing Results</h4>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                  <span className="text-gray-600">Base Cost:</span>
                  <span className="font-medium">₹{result.baseCost}</span>
                </div>
                
                {result.transportCost > 0 && (
                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-gray-600">Transport Cost:</span>
                    <span className="font-medium">₹{result.transportCost}</span>
                  </div>
                )}

                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                  <span className="text-gray-600">Wholesale Price:</span>
                  <span className="font-medium text-blue-600">₹{result.wholesalePrice}</span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                  <span className="text-gray-600">GST Amount:</span>
                  <span className="font-medium">₹{result.gstAmount}</span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                  <span className="text-gray-600">Retail Price (with GST):</span>
                  <span className="font-medium text-green-600">₹{result.retailPrice}</span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-gray-100">
                  <span className="text-gray-600">Competitive Price:</span>
                  <span className="font-medium text-orange-600">₹{result.competitivePrice}</span>
                </div>

                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Total Profit:</span>
                  <span className="font-medium text-purple-600">₹{result.totalProfit}</span>
                </div>
              </div>

              <div className="mt-4 p-3 bg-amber-50 rounded-lg">
                <p className="text-sm text-amber-800">
                  <strong>Recommendation:</strong> Set retail price at ₹{result.retailPrice} for {result.profitMargin}% margin, 
                  or ₹{result.competitivePrice} for competitive pricing.
                </p>
              </div>
            </div>
          )}

          {/* GST Guide */}
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h4 className="font-medium text-gray-900 mb-4">GST Rates for Textiles</h4>
            <div className="space-y-2">
              {gstSlabs.map((slab, index) => (
                <div key={index} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                  <span className="font-medium text-gray-900">{slab.rate}</span>
                  <span className="text-sm text-gray-600">{slab.description}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
