import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { AIChat } from "./AIChat";
import { SupplierFinder } from "./SupplierFinder";
import { PricingCalculator } from "./PricingCalculator";
import { InvoiceGenerator } from "./InvoiceGenerator";
import { Analytics } from "./Analytics";
import { ProductCatalog } from "./ProductCatalog";

interface DashboardProps {
  profile: any;
}

type TabType = "chat" | "suppliers" | "pricing" | "products" | "invoices" | "analytics";

export function Dashboard({ profile }: DashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>("chat");
  const salesAnalytics = useQuery(api.invoices.getSalesAnalytics, {});

  const tabs = [
    { id: "chat", name: "AI Assistant", icon: "🤖" },
    { id: "suppliers", name: "Suppliers", icon: "🏭" },
    { id: "pricing", name: "Pricing", icon: "💰" },
    { id: "products", name: "Products", icon: "🧵" },
    { id: "invoices", name: "Invoices", icon: "📄" },
    { id: "analytics", name: "Analytics", icon: "📊" },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2">
              Welcome back, {profile.ownerName}!
            </h2>
            <p className="text-amber-100">
              {profile.shopName} • {profile.location}
            </p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">
              ₹{salesAnalytics?.totalSales?.toLocaleString() || "0"}
            </div>
            <div className="text-amber-100">Total Sales</div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 border border-amber-200">
          <div className="text-2xl font-bold text-gray-900">
            {salesAnalytics?.totalInvoices || 0}
          </div>
          <div className="text-gray-600">Total Invoices</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-amber-200">
          <div className="text-2xl font-bold text-gray-900">
            ₹{Math.round(salesAnalytics?.averageOrderValue || 0).toLocaleString()}
          </div>
          <div className="text-gray-600">Avg Order Value</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-amber-200">
          <div className="text-2xl font-bold text-gray-900">
            ₹{salesAnalytics?.totalGST?.toLocaleString() || "0"}
          </div>
          <div className="text-gray-600">GST Collected</div>
        </div>
        <div className="bg-white rounded-xl p-4 border border-amber-200">
          <div className="text-2xl font-bold text-green-600">
            {profile.businessType.replace("_", " ").toUpperCase()}
          </div>
          <div className="text-gray-600">Business Type</div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-xl border border-amber-200 overflow-hidden">
        <div className="border-b border-amber-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? "border-amber-500 text-amber-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.name}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "chat" && <AIChat profile={profile} />}
          {activeTab === "suppliers" && <SupplierFinder />}
          {activeTab === "pricing" && <PricingCalculator />}
          {activeTab === "products" && <ProductCatalog />}
          {activeTab === "invoices" && <InvoiceGenerator />}
          {activeTab === "analytics" && <Analytics />}
        </div>
      </div>
    </div>
  );
}
