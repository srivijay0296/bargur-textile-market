import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface InvoiceItem {
  productId: string;
  clothName: string;
  quantity: number;
  pricePerMeter: number;
  totalPrice: number;
}

export function InvoiceGenerator() {
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "upi" | "card" | "credit">("cash");
  const [notes, setNotes] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const createInvoice = useMutation(api.invoices.createInvoice);
  const userInvoices = useQuery(api.invoices.getUserInvoices, { limit: 10 });
  const products = useQuery(api.products.getProducts, {});

  const addItem = () => {
    setItems([...items, {
      productId: "",
      clothName: "",
      quantity: 0,
      pricePerMeter: 0,
      totalPrice: 0,
    }]);
  };

  const updateItem = (index: number, field: keyof InvoiceItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    
    // Auto-calculate total price
    if (field === "quantity" || field === "pricePerMeter") {
      newItems[index].totalPrice = newItems[index].quantity * newItems[index].pricePerMeter;
    }
    
    setItems(newItems);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const calculateSubtotal = () => {
    return items.reduce((sum, item) => sum + item.totalPrice, 0);
  };

  const calculateGST = () => {
    return calculateSubtotal() * 0.12; // 12% GST for textiles
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateGST();
  };

  const handleGenerateInvoice = async () => {
    if (!customerName || items.length === 0) {
      toast.error("Please fill customer name and add at least one item");
      return;
    }

    setIsGenerating(true);
    try {
      await createInvoice({
        customerName,
        customerPhone: customerPhone || undefined,
        items: items.map(item => ({
          productId: item.productId as any,
          clothName: item.clothName,
          quantity: item.quantity,
          pricePerMeter: item.pricePerMeter,
          totalPrice: item.totalPrice,
        })),
        paymentMethod,
        notes: notes || undefined,
      });

      toast.success("Invoice generated successfully!");
      
      // Reset form
      setCustomerName("");
      setCustomerPhone("");
      setItems([]);
      setNotes("");
    } catch (error) {
      toast.error("Failed to generate invoice");
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleWhatsAppShare = (invoice: any) => {
    const message = encodeURIComponent(
      `*INVOICE - ${invoice.invoiceNumber}*\n\n` +
      `Customer: ${invoice.customerName}\n` +
      `Date: ${new Date(invoice._creationTime).toLocaleDateString()}\n\n` +
      `Items:\n${invoice.items.map((item: any) => 
        `• ${item.clothName} - ${item.quantity}m @ ₹${item.pricePerMeter} = ₹${item.totalPrice}`
      ).join('\n')}\n\n` +
      `Subtotal: ₹${invoice.subtotal}\n` +
      `GST (12%): ₹${invoice.gstAmount}\n` +
      `*Total: ₹${invoice.totalAmount}*\n\n` +
      `Payment: ${invoice.paymentMethod.toUpperCase()}\n` +
      `Status: ${invoice.paymentStatus.toUpperCase()}\n\n` +
      `Thank you for your business!\n` +
      `- Bargur Textile AI`
    );
    
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg p-4 border border-emerald-200">
        <h3 className="font-semibold text-emerald-900 mb-2">GST Invoice Generator</h3>
        <p className="text-emerald-700 text-sm">
          Create professional GST-compliant invoices with automatic calculations
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Invoice Form */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Create New Invoice</h4>
          
          <div className="space-y-4">
            {/* Customer Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Customer Name *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  placeholder="Enter customer name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  placeholder="Enter phone number"
                />
              </div>
            </div>

            {/* Items */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <label className="block text-sm font-medium text-gray-700">
                  Invoice Items
                </label>
                <button
                  onClick={addItem}
                  className="px-3 py-1 bg-amber-500 text-white text-sm rounded-lg hover:bg-amber-600 transition-colors"
                >
                  Add Item
                </button>
              </div>
              
              <div className="space-y-3">
                {items.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 gap-2 items-end">
                    <div className="col-span-4">
                      <input
                        type="text"
                        value={item.clothName}
                        onChange={(e) => updateItem(index, "clothName", e.target.value)}
                        placeholder="Cloth name"
                        className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                    <div className="col-span-2">
                      <input
                        type="number"
                        value={item.quantity || ""}
                        onChange={(e) => updateItem(index, "quantity", parseFloat(e.target.value) || 0)}
                        placeholder="Qty"
                        className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                    <div className="col-span-2">
                      <input
                        type="number"
                        value={item.pricePerMeter || ""}
                        onChange={(e) => updateItem(index, "pricePerMeter", parseFloat(e.target.value) || 0)}
                        placeholder="Price"
                        className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                    <div className="col-span-3">
                      <div className="px-2 py-1 bg-gray-50 rounded text-sm font-medium">
                        ₹{item.totalPrice.toFixed(2)}
                      </div>
                    </div>
                    <div className="col-span-1">
                      <button
                        onClick={() => removeItem(index)}
                        className="p-1 text-red-500 hover:text-red-700"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              >
                <option value="cash">Cash</option>
                <option value="upi">UPI</option>
                <option value="card">Card</option>
                <option value="credit">Credit</option>
              </select>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="Additional notes..."
              />
            </div>

            {/* Invoice Summary */}
            {items.length > 0 && (
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>₹{calculateSubtotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST (12%):</span>
                    <span>₹{calculateGST().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg border-t border-gray-200 pt-2">
                    <span>Total:</span>
                    <span>₹{calculateTotal().toFixed(2)}</span>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={handleGenerateInvoice}
              disabled={!customerName || items.length === 0 || isGenerating}
              className="w-full bg-emerald-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isGenerating ? "Generating..." : "Generate Invoice"}
            </button>
          </div>
        </div>

        {/* Recent Invoices */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Recent Invoices</h4>
          
          <div className="space-y-3">
            {userInvoices?.map((invoice) => (
              <div key={invoice._id} className="border border-gray-200 rounded-lg p-3">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium text-gray-900">{invoice.invoiceNumber}</div>
                    <div className="text-sm text-gray-600">{invoice.customerName}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-green-600">₹{invoice.totalAmount}</div>
                    <div className={`text-xs px-2 py-1 rounded-full ${
                      invoice.paymentStatus === "paid" 
                        ? "bg-green-100 text-green-800"
                        : invoice.paymentStatus === "pending"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-orange-100 text-orange-800"
                    }`}>
                      {invoice.paymentStatus.toUpperCase()}
                    </div>
                  </div>
                </div>
                
                <div className="text-xs text-gray-500 mb-2">
                  {new Date(invoice._creationTime).toLocaleDateString()} • {invoice.items.length} items
                </div>
                
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleWhatsAppShare(invoice)}
                    className="flex-1 bg-green-500 text-white py-1 px-2 rounded text-xs font-medium hover:bg-green-600 transition-colors"
                  >
                    Share WhatsApp
                  </button>
                  <button className="flex-1 bg-blue-500 text-white py-1 px-2 rounded text-xs font-medium hover:bg-blue-600 transition-colors">
                    Download PDF
                  </button>
                </div>
              </div>
            ))}
          </div>

          {userInvoices?.length === 0 && (
            <div className="text-center py-8">
              <div className="text-gray-400 text-4xl mb-2">📄</div>
              <p className="text-gray-600">No invoices yet</p>
              <p className="text-sm text-gray-500 mt-1">Create your first invoice</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
