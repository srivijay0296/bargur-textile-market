import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function Analytics() {
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
  });

  const salesAnalytics = useQuery(api.invoices.getSalesAnalytics, {
    startDate: dateRange.startDate,
    endDate: dateRange.endDate,
  });

  const allTimeAnalytics = useQuery(api.invoices.getSalesAnalytics, {});

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const calculateGrowth = (current: number, previous: number) => {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-violet-50 to-purple-50 rounded-lg p-4 border border-violet-200">
        <h3 className="font-semibold text-violet-900 mb-2">Business Analytics Dashboard</h3>
        <p className="text-violet-700 text-sm">
          Track your sales performance, top products, and business growth metrics
        </p>
      </div>

      {/* Date Range Selector */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h4 className="font-medium text-gray-900 mb-4">Select Date Range</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Start Date
            </label>
            <input
              type="date"
              value={dateRange.startDate}
              onChange={(e) => setDateRange({ ...dateRange, startDate: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              End Date
            </label>
            <input
              type="date"
              value={dateRange.endDate}
              onChange={(e) => setDateRange({ ...dateRange, endDate: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Sales</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(salesAnalytics?.totalSales || 0)}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">💰</span>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-gray-500">
              All time: {formatCurrency(allTimeAnalytics?.totalSales || 0)}
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Invoices</p>
              <p className="text-2xl font-bold text-gray-900">
                {salesAnalytics?.totalInvoices || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">📄</span>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-gray-500">
              All time: {allTimeAnalytics?.totalInvoices || 0}
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Order Value</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(salesAnalytics?.averageOrderValue || 0)}
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">📊</span>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-gray-500">
              All time: {formatCurrency(allTimeAnalytics?.averageOrderValue || 0)}
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">GST Collected</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(salesAnalytics?.totalGST || 0)}
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <span className="text-2xl">🏛️</span>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-gray-500">
              All time: {formatCurrency(allTimeAnalytics?.totalGST || 0)}
            </span>
          </div>
        </div>
      </div>

      {/* Top Selling Products */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Top Selling Products</h4>
        
        {salesAnalytics?.topSellingItems && salesAnalytics.topSellingItems.length > 0 ? (
          <div className="space-y-4">
            {salesAnalytics.topSellingItems.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <h5 className="font-medium text-gray-900">{item.name}</h5>
                    <p className="text-sm text-gray-600">{item.quantity} meters sold</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-green-600">{formatCurrency(item.revenue)}</div>
                  <div className="text-sm text-gray-500">Revenue</div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="text-gray-400 text-4xl mb-2">📈</div>
            <p className="text-gray-600">No sales data available</p>
            <p className="text-sm text-gray-500 mt-1">Start creating invoices to see analytics</p>
          </div>
        )}
      </div>

      {/* Business Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Business Insights</h4>
          
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h5 className="font-medium text-blue-900 mb-2">💡 Revenue Optimization</h5>
              <p className="text-sm text-blue-700">
                {salesAnalytics?.averageOrderValue && salesAnalytics.averageOrderValue < 5000
                  ? "Consider bundling products or offering bulk discounts to increase average order value."
                  : "Great job! Your average order value is healthy. Focus on customer retention."
                }
              </p>
            </div>

            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <h5 className="font-medium text-green-900 mb-2">📊 Sales Performance</h5>
              <p className="text-sm text-green-700">
                {salesAnalytics?.totalInvoices && salesAnalytics.totalInvoices > 10
                  ? "Excellent sales activity! Consider expanding your product range."
                  : "Focus on marketing and customer acquisition to boost sales volume."
                }
              </p>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <h5 className="font-medium text-purple-900 mb-2">🎯 Growth Strategy</h5>
              <p className="text-sm text-purple-700">
                Based on your top-selling products, consider stocking similar items and negotiating better rates with suppliers.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Monthly Trends</h4>
          
          <div className="space-y-4">
            <div className="text-center py-8">
              <div className="text-gray-400 text-4xl mb-2">📈</div>
              <p className="text-gray-600">Monthly trend analysis</p>
              <p className="text-sm text-gray-500 mt-1">
                Track your business growth over time
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Export Options */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Export Reports</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="flex items-center justify-center space-x-2 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <span>📊</span>
            <span>Sales Report (PDF)</span>
          </button>
          
          <button className="flex items-center justify-center space-x-2 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <span>📈</span>
            <span>Analytics (Excel)</span>
          </button>
          
          <button className="flex items-center justify-center space-x-2 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <span>🏛️</span>
            <span>GST Report</span>
          </button>
        </div>
      </div>
    </div>
  );
}
