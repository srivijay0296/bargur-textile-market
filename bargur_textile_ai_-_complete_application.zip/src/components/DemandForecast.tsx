import { useState } from "react";
import { useQuery, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function DemandForecast() {
  const [selectedCloth, setSelectedCloth] = useState("Cotton Shirting");
  const [region, setRegion] = useState("Bargur");
  const [isGenerating, setIsGenerating] = useState(false);

  const generateForecast = useAction(api.demandForecast.generateSeasonalForecast);
  const forecasts = useQuery(api.demandForecast.getForecast, {
    clothType: selectedCloth,
    region: region,
    months: 6,
  });
  
  const recommendations = useQuery(api.demandForecast.getBusinessRecommendations, {
    region: region,
  });

  const clothTypes = [
    "Cotton Shirting",
    "Cotton Saree", 
    "Silk Saree",
    "Polyester Suiting",
    "Linen Fabric",
    "Cotton Dhoti",
    "Silk Blouse"
  ];

  const regions = [
    "Bargur",
    "Krishnagiri", 
    "Hosur",
    "Dharmapuri",
    "Salem"
  ];

  const handleGenerateForecast = async () => {
    setIsGenerating(true);
    try {
      await generateForecast({
        clothType: selectedCloth,
        region: region,
      });
      toast.success("Demand forecast generated successfully!");
    } catch (error) {
      toast.error("Failed to generate forecast");
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const getDemandColor = (demand: number) => {
    if (demand >= 120) return "text-red-600 bg-red-50";
    if (demand >= 100) return "text-green-600 bg-green-50";
    return "text-blue-600 bg-blue-50";
  };

  const getDemandLabel = (demand: number) => {
    if (demand >= 120) return "High Demand";
    if (demand >= 100) return "Normal Demand";
    return "Low Demand";
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      default: return "bg-blue-100 text-blue-800";
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg p-4 border border-cyan-200">
        <h3 className="font-semibold text-cyan-900 mb-2">AI Demand Forecast Engine</h3>
        <p className="text-cyan-700 text-sm">
          Predict seasonal demand patterns for textile products using AI analysis of festivals, weather, and market trends
        </p>
      </div>

      {/* Forecast Generator */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Generate New Forecast</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cloth Type
            </label>
            <select
              value={selectedCloth}
              onChange={(e) => setSelectedCloth(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              {clothTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Region
            </label>
            <select
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              {regions.map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleGenerateForecast}
              disabled={isGenerating}
              className="w-full bg-cyan-500 text-white py-2 px-4 rounded-lg font-medium hover:bg-cyan-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isGenerating ? "Generating..." : "Generate Forecast"}
            </button>
          </div>
        </div>
      </div>

      {/* Forecast Results */}
      {forecasts && forecasts.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">
            6-Month Demand Forecast: {selectedCloth} in {region}
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {forecasts.slice(0, 6).map((forecast, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h5 className="font-medium text-gray-900">
                      {new Date(forecast.month + "-01").toLocaleDateString('en-US', { 
                        month: 'long', 
                        year: 'numeric' 
                      })}
                    </h5>
                    <div className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getDemandColor(forecast.predictedDemand)}`}>
                      {getDemandLabel(forecast.predictedDemand)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-gray-900">
                      {forecast.predictedDemand}%
                    </div>
                    <div className="text-xs text-gray-500">
                      {Math.round(forecast.confidence * 100)}% confidence
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-700">Factors:</div>
                  <div className="space-y-1">
                    {forecast.factors.slice(0, 3).map((factor, i) => (
                      <div key={i} className="text-xs text-gray-600 bg-gray-50 px-2 py-1 rounded">
                        {factor}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Business Recommendations */}
      {recommendations && recommendations.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">AI Business Recommendations</h4>
          
          <div className="space-y-4">
            {recommendations.map((rec, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <h5 className="font-medium text-gray-900">{rec.title}</h5>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(rec.priority)}`}>
                        {rec.priority.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{rec.description}</p>
                  </div>
                  <div className="text-2xl">
                    {rec.type === "stock_up" && "📈"}
                    {rec.type === "clearance" && "🏷️"}
                    {rec.type === "festival" && "🎉"}
                    {rec.type === "seasonal" && "🌟"}
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-3">
                  <div className="text-sm font-medium text-amber-800 mb-1">Recommended Action:</div>
                  <div className="text-sm text-amber-700">{rec.action}</div>
                </div>

                <div className="flex flex-wrap gap-1">
                  {rec.products.slice(0, 5).map((product, i) => (
                    <span key={i} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                      {product}
                    </span>
                  ))}
                  {rec.products.length > 5 && (
                    <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                      +{rec.products.length - 5} more
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Market Intelligence */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Seasonal Trends</h4>
          
          <div className="space-y-4">
            <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
              <h5 className="font-medium text-orange-900 mb-2">🌞 Summer Season (Mar-May)</h5>
              <p className="text-sm text-orange-700">
                High demand for cotton and linen fabrics. Focus on light, breathable materials.
              </p>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h5 className="font-medium text-blue-900 mb-2">🌧️ Monsoon Season (Jun-Sep)</h5>
              <p className="text-sm text-blue-700">
                Lower overall demand. Good time for inventory clearance and supplier negotiations.
              </p>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <h5 className="font-medium text-purple-900 mb-2">🎉 Festival Season (Oct-Dec)</h5>
              <p className="text-sm text-purple-700">
                Peak demand for silk and premium fabrics. Wedding season drives high-value sales.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h4 className="font-medium text-gray-900 mb-4">Festival Calendar Impact</h4>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Pongal (Jan)</div>
                <div className="text-sm text-gray-600">Traditional wear demand</div>
              </div>
              <div className="text-green-600 font-medium">+15%</div>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Tamil New Year (Apr)</div>
                <div className="text-sm text-gray-600">New clothing purchases</div>
              </div>
              <div className="text-green-600 font-medium">+20%</div>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Diwali (Oct/Nov)</div>
                <div className="text-sm text-gray-600">Peak festival demand</div>
              </div>
              <div className="text-red-600 font-medium">+40%</div>
            </div>

            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">Wedding Season (Nov-Feb)</div>
                <div className="text-sm text-gray-600">Premium silk demand</div>
              </div>
              <div className="text-red-600 font-medium">+60%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
