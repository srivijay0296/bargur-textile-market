import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { supabase } from '@/lib/supabase';
import { useCart } from '@/contexts/CartContext';
import { useAuth } from '@/contexts/AuthContext';
import { formatPrice, STRIPE_ACCOUNT_ID, SHIPPING_RULES } from '@/lib/constants';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import { ChevronRight, Lock, Truck, ShieldCheck } from 'lucide-react';

const stripePromise = STRIPE_ACCOUNT_ID && STRIPE_ACCOUNT_ID !== 'STRIPE_ACCOUNT_ID'
  ? loadStripe('pk_live_51OJhJBHdGQpsHqInIzu7c6PzGPSH0yImD4xfpofvxvFZs0VFhPRXZCyEgYkkhOtBOXFWvssYASs851mflwQvjnrl00T6DbUwWZ', { stripeAccount: STRIPE_ACCOUNT_ID })
  : null;

function PaymentForm({ onSuccess }: { onSuccess: (pi: any) => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setLoading(true);
    setError('');

    const { error: submitError, paymentIntent } = await stripe.confirmPayment({
      elements,
      redirect: 'if_required',
    });

    if (submitError) {
      setError(submitError.message || 'Payment failed');
      setLoading(false);
    } else if (paymentIntent?.status === 'succeeded') {
      onSuccess(paymentIntent);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <PaymentElement />
      {error && <p className="text-red-500 text-sm mt-3">{error}</p>}
      <button
        type="submit"
        disabled={!stripe || loading}
        className="w-full mt-4 py-3.5 bg-[#F97316] text-white rounded-xl font-bold hover:bg-orange-600 transition disabled:opacity-50 flex items-center justify-center gap-2"
      >
        <Lock className="w-4 h-4" />
        {loading ? 'Processing Payment...' : 'Pay Now'}
      </button>
    </form>
  );
}

export default function CheckoutPage() {
  const { cart, cartTotal, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [clientSecret, setClientSecret] = useState('');
  const [paymentError, setPaymentError] = useState('');
  const [shippingCost, setShippingCost] = useState(0);
  const [step, setStep] = useState<'shipping' | 'payment'>('shipping');
  const [shippingAddress, setShippingAddress] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: '',
    city: 'Bargur',
    state: 'Tamil Nadu',
    zip: '',
    country: 'India',
  });

  useEffect(() => {
    if (cart.length === 0) {
      navigate('/cart');
    }
  }, [cart, navigate]);

  useEffect(() => {
    // Calculate shipping
    const calcShipping = async () => {
      const { data } = await supabase.functions.invoke('calculate-shipping', {
        body: {
          cartItems: cart.map(item => ({ name: item.name, quantity: item.quantity, price: item.price })),
          shippingRules: SHIPPING_RULES,
          subtotal: cartTotal,
        },
      });
      if (data?.success) setShippingCost(data.shippingCents);
    };
    if (cart.length > 0) calcShipping();
  }, [cart, cartTotal]);

  const total = cartTotal + shippingCost;

  const handleShippingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingAddress.name || !shippingAddress.email || !shippingAddress.address || !shippingAddress.zip) return;

    // Create payment intent
    const { data, error } = await supabase.functions.invoke('create-payment-intent', {
      body: { amount: total, currency: 'inr' },
    });

    if (error || !data?.clientSecret) {
      setPaymentError('Unable to initialize payment. Please try again.');
      setStep('payment');
      return;
    }

    setClientSecret(data.clientSecret);
    setStep('payment');
  };

  const handlePaymentSuccess = async (paymentIntent: any) => {
    // Create customer
    const { data: customer } = await supabase
      .from('ecom_customers')
      .upsert({ email: shippingAddress.email, name: shippingAddress.name, phone: shippingAddress.phone }, { onConflict: 'email' })
      .select('id')
      .single();

    // Create order
    const { data: order } = await supabase
      .from('ecom_orders')
      .insert({
        customer_id: customer?.id,
        status: 'paid',
        subtotal: cartTotal,
        tax: 0,
        shipping: shippingCost,
        total,
        shipping_address: shippingAddress,
        stripe_payment_intent_id: paymentIntent.id,
      })
      .select('id')
      .single();

    if (order) {
      const orderItems = cart.map(item => ({
        order_id: order.id,
        product_id: item.product_id,
        variant_id: item.variant_id || null,
        product_name: item.name,
        variant_title: item.variant_title || null,
        sku: item.sku || null,
        quantity: item.quantity,
        unit_price: item.price,
        total: item.price * item.quantity,
      }));
      await supabase.from('ecom_order_items').insert(orderItems);

      // Send confirmation email
      await supabase.functions.invoke('send-order-confirmation', {
        body: {
          orderId: order.id,
          customerEmail: shippingAddress.email,
          customerName: shippingAddress.name,
          orderItems,
          subtotal: cartTotal,
          shipping: shippingCost,
          tax: 0,
          total,
          shippingAddress,
        },
      });

      clearCart();
      navigate(`/order-confirmation?orderId=${order.id}`);
    }
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 text-sm text-gray-500">
          <Link to="/" className="hover:text-[#1E3A8A]">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to="/cart" className="hover:text-[#1E3A8A]">Cart</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-gray-900 font-medium">Checkout</span>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Steps */}
        <div className="flex items-center gap-4 mb-8">
          {['Shipping', 'Payment'].map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                (i === 0 && step === 'shipping') || (i === 1 && step === 'payment')
                  ? 'bg-[#1E3A8A] text-white'
                  : i === 0 && step === 'payment'
                  ? 'bg-green-500 text-white'
                  : 'bg-gray-200 text-gray-500'
              }`}>
                {i === 0 && step === 'payment' ? '✓' : i + 1}
              </div>
              <span className={`text-sm font-medium ${
                (i === 0 && step === 'shipping') || (i === 1 && step === 'payment') ? 'text-gray-900' : 'text-gray-400'
              }`}>{s}</span>
              {i < 1 && <div className="w-12 h-0.5 bg-gray-200 mx-2" />}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Form */}
          <div className="lg:col-span-3">
            {step === 'shipping' && (
              <form onSubmit={handleShippingSubmit} className="bg-white rounded-2xl border p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Shipping Address</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                    <input type="text" required value={shippingAddress.name} onChange={e => setShippingAddress({ ...shippingAddress, name: e.target.value })}
                      className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                    <input type="email" required value={shippingAddress.email} onChange={e => setShippingAddress({ ...shippingAddress, email: e.target.value })}
                      className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="tel" value={shippingAddress.phone} onChange={e => setShippingAddress({ ...shippingAddress, phone: e.target.value })}
                      className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Address *</label>
                    <input type="text" required value={shippingAddress.address} onChange={e => setShippingAddress({ ...shippingAddress, address: e.target.value })}
                      className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" placeholder="Street address, area" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                    <input type="text" value={shippingAddress.city} onChange={e => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                      className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                    <input type="text" value={shippingAddress.state} onChange={e => setShippingAddress({ ...shippingAddress, state: e.target.value })}
                      className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">PIN Code *</label>
                    <input type="text" required value={shippingAddress.zip} onChange={e => setShippingAddress({ ...shippingAddress, zip: e.target.value })}
                      className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                    <input type="text" value={shippingAddress.country} readOnly
                      className="w-full px-4 py-2.5 border-2 rounded-xl bg-gray-50 text-sm" />
                  </div>
                </div>
                <button type="submit" className="w-full mt-6 py-3.5 bg-[#1E3A8A] text-white rounded-xl font-bold hover:bg-blue-800 transition">
                  Continue to Payment
                </button>
              </form>
            )}

            {step === 'payment' && (
              <div className="bg-white rounded-2xl border p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-bold text-gray-900">Payment</h2>
                  <button onClick={() => setStep('shipping')} className="text-sm text-[#1E3A8A] hover:underline">Edit Shipping</button>
                </div>

                {/* Shipping summary */}
                <div className="bg-gray-50 rounded-xl p-4 mb-6 text-sm">
                  <p className="font-medium">{shippingAddress.name}</p>
                  <p className="text-gray-500">{shippingAddress.address}, {shippingAddress.city}, {shippingAddress.state} {shippingAddress.zip}</p>
                  <p className="text-gray-500">{shippingAddress.email} | {shippingAddress.phone}</p>
                </div>

                {!stripePromise ? (
                  <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-xl">
                    <p className="text-yellow-800 font-medium">Payment processing is being set up</p>
                    <p className="text-yellow-600 text-sm mt-1">Please check back soon. The store owner needs to connect their payment account.</p>
                  </div>
                ) : paymentError ? (
                  <div className="bg-red-50 border border-red-200 p-4 rounded-xl">
                    <p className="text-red-800">{paymentError}</p>
                  </div>
                ) : clientSecret ? (
                  <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
                    <PaymentForm onSuccess={handlePaymentSuccess} />
                  </Elements>
                ) : (
                  <div className="flex items-center justify-center py-8">
                    <div className="w-8 h-8 border-4 border-[#1E3A8A] border-t-transparent rounded-full animate-spin" />
                    <span className="ml-3 text-gray-600">Loading payment form...</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl border p-6 sticky top-20">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Order Summary</h3>
              <div className="space-y-3 mb-4">
                {cart.map(item => (
                  <div key={item.product_id + (item.variant_id || '')} className="flex gap-3">
                    <img src={item.image || '/placeholder.svg'} alt={item.name} className="w-14 h-14 object-cover rounded-lg" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.name}</p>
                      {item.variant_title && <p className="text-xs text-gray-500">{item.variant_title}</p>}
                      <p className="text-xs text-gray-400">Qty: {item.quantity}</p>
                    </div>
                    <p className="text-sm font-semibold">{formatPrice(item.price * item.quantity)}</p>
                  </div>
                ))}
              </div>
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span>{formatPrice(cartTotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Shipping</span>
                  <span className="text-green-600 flex items-center gap-1"><Truck className="w-3.5 h-3.5" /> Free</span>
                </div>
                <div className="border-t pt-2 flex justify-between">
                  <span className="font-bold">Total</span>
                  <span className="text-xl font-bold text-[#1E3A8A]">{formatPrice(total)}</span>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2 text-xs text-gray-500">
                <ShieldCheck className="w-4 h-4 text-green-600" />
                Secure checkout - Your data is encrypted
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
