import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/lib/constants';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import ProductCard from '@/components/ProductCard';
import { ChevronRight, MapPin, Store, Minus, Plus, ShoppingCart, Truck, ShieldCheck, MessageCircle, Tag, Package } from 'lucide-react';

export default function ProductPage() {
  const { handle } = useParams<{ handle: string }>();
  const { addToCart } = useCart();
  const [product, setProduct] = useState<any>(null);
  const [selectedVariant, setSelectedVariant] = useState<any>(null);
  const [selectedOption, setSelectedOption] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [relatedProducts, setRelatedProducts] = useState<any[]>([]);
  const [addedToCart, setAddedToCart] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!handle) return;
      setLoading(true);
      setSelectedVariant(null);
      setSelectedOption('');
      setQuantity(1);
      setAddedToCart(false);

      const { data } = await supabase
        .from('ecom_products')
        .select('*, variants:ecom_product_variants(*)')
        .eq('handle', handle)
        .single();

      if (data) {
        let variants = data.variants || [];
        if (data.has_variants && variants.length === 0) {
          const { data: variantData } = await supabase
            .from('ecom_product_variants')
            .select('*')
            .eq('product_id', data.id)
            .order('position');
          variants = variantData || [];
          data.variants = variants;
        }

        setProduct(data);

        if (variants.length > 0) {
          const sorted = [...variants].sort((a: any, b: any) => (a.position || 0) - (b.position || 0));
          const firstInStock = sorted.find((v: any) => v.inventory_qty == null || v.inventory_qty > 0) || sorted[0];
          setSelectedVariant(firstInStock);
          setSelectedOption(firstInStock?.option1 || '');
        }

        // Fetch related products
        const { data: related } = await supabase
          .from('ecom_products')
          .select('*, variants:ecom_product_variants(*)')
          .eq('status', 'active')
          .neq('id', data.id)
          .limit(4);
        if (related) setRelatedProducts(related);
      }
      setLoading(false);
    };
    fetchProduct();
  }, [handle]);

  const handleOptionSelect = (option: string) => {
    setSelectedOption(option);
    const variant = product?.variants?.find((v: any) =>
      v.option1 === option || v.title?.toLowerCase().includes(option.toLowerCase())
    );
    if (variant) setSelectedVariant(variant);
  };

  const variantOptions = [...new Set(product?.variants?.map((v: any) => v.option1).filter(Boolean) || [])];
  const hasVariants = product?.has_variants && product?.variants?.length > 0;

  const getInStock = (): boolean => {
    if (selectedVariant) {
      if (selectedVariant.inventory_qty == null) return true;
      return selectedVariant.inventory_qty > 0;
    }
    if (product?.variants && product.variants.length > 0) {
      return product.variants.some((v: any) => v.inventory_qty == null || v.inventory_qty > 0);
    }
    if (product?.has_variants) return true;
    if (product?.inventory_qty == null) return true;
    return product.inventory_qty > 0;
  };
  const inStock = getInStock();

  const handleAddToCart = () => {
    if (!product) return;
    if (hasVariants && !selectedOption) return;
    if (!inStock) return;

    addToCart({
      product_id: product.id,
      variant_id: selectedVariant?.id || undefined,
      name: product.name,
      variant_title: selectedVariant?.title || selectedOption || undefined,
      sku: selectedVariant?.sku || product.sku || product.handle,
      price: selectedVariant?.price || product.price,
      image: product.images?.[0],
      vendor: product.vendor,
    }, quantity);

    setAddedToCart(true);
    setTimeout(() => setAddedToCart(false), 2000);
  };

  const currentPrice = selectedVariant?.price || product?.price || 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F9FAFB]">
        <Header /><AuthModal /><CartDrawer />
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="aspect-square bg-gray-200 rounded-2xl animate-pulse" />
            <div className="space-y-4">
              <div className="h-8 bg-gray-200 rounded w-3/4 animate-pulse" />
              <div className="h-6 bg-gray-200 rounded w-1/3 animate-pulse" />
              <div className="h-20 bg-gray-200 rounded animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-[#F9FAFB]">
        <Header /><AuthModal /><CartDrawer />
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <Package className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-gray-700">Product not found</h2>
          <Link to="/products" className="mt-4 inline-block text-[#1E3A8A] font-medium hover:underline">Browse all products</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 text-sm text-gray-500">
          <Link to="/" className="hover:text-[#1E3A8A]">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <Link to="/products" className="hover:text-[#1E3A8A]">Products</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-gray-900 font-medium truncate">{product.name}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Image */}
          <div className="space-y-4">
            <div className="aspect-square rounded-2xl overflow-hidden bg-white border">
              <img src={product.images?.[0] || '/placeholder.svg'} alt={product.name} className="w-full h-full object-cover" />
            </div>
            {product.images?.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {product.images.slice(0, 4).map((img: string, i: number) => (
                  <div key={i} className="aspect-square rounded-lg overflow-hidden border-2 border-transparent hover:border-[#1E3A8A] cursor-pointer transition">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div>
            {/* Vendor */}
            {product.vendor && (
              <div className="flex items-center gap-2 mb-3">
                <Store className="w-4 h-4 text-[#F97316]" />
                <span className="text-sm font-medium text-gray-600">{product.vendor}</span>
                {product.metadata?.market && (
                  <>
                    <span className="text-gray-300">|</span>
                    <MapPin className="w-3.5 h-3.5 text-gray-400" />
                    <span className="text-sm text-gray-500">{product.metadata.market}</span>
                  </>
                )}
              </div>
            )}

            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>

            {product.product_type && (
              <div className="flex items-center gap-1.5 mb-4">
                <Tag className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-500">{product.product_type}</span>
              </div>
            )}

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-6">
              <span className="text-3xl font-bold text-[#1E3A8A]">{formatPrice(currentPrice)}</span>
              {product.metadata?.weight && (
                <span className="text-sm text-gray-500">/ {product.metadata.weight}</span>
              )}
              {inStock ? (
                <span className="text-sm font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">In Stock</span>
              ) : (
                <span className="text-sm font-medium text-red-600 bg-red-50 px-2 py-0.5 rounded-full">Out of Stock</span>
              )}
            </div>

            {/* Description */}
            <p className="text-gray-600 mb-6 leading-relaxed">{product.description}</p>

            {/* Metadata */}
            {product.metadata && (
              <div className="grid grid-cols-2 gap-3 mb-6">
                {Object.entries(product.metadata)
                  .filter(([key]) => !['shop_id', 'market'].includes(key))
                  .map(([key, value]) => (
                    <div key={key} className="bg-gray-50 rounded-xl p-3">
                      <p className="text-xs text-gray-400 capitalize">{key.replace(/_/g, ' ')}</p>
                      <p className="text-sm font-medium text-gray-800">{String(value)}</p>
                    </div>
                  ))}
              </div>
            )}

            {/* Variant selector */}
            {variantOptions.length > 0 && (
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-800 mb-3">Select Option</label>
                <div className="flex flex-wrap gap-2">
                  {variantOptions.map((opt: string) => {
                    const variant = product.variants?.find((v: any) => v.option1 === opt);
                    const optInStock = variant ? (variant.inventory_qty == null || variant.inventory_qty > 0) : true;
                    return (
                      <button
                        key={opt}
                        onClick={() => optInStock && handleOptionSelect(opt)}
                        disabled={!optInStock}
                        className={`px-5 py-2.5 border-2 rounded-xl font-medium text-sm transition-all ${
                          selectedOption === opt
                            ? 'bg-[#1E3A8A] text-white border-[#1E3A8A]'
                            : optInStock
                            ? 'border-gray-200 hover:border-[#1E3A8A] text-gray-700'
                            : 'border-gray-100 text-gray-300 cursor-not-allowed line-through'
                        }`}
                      >
                        {opt}
                        {variant && <span className="ml-1 text-xs opacity-75">({formatPrice(variant.price)})</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-800 mb-3">Quantity</label>
              <div className="flex items-center gap-1 bg-gray-100 rounded-xl w-fit">
                <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="p-3 hover:bg-gray-200 rounded-l-xl transition">
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-6 py-3 font-semibold text-lg min-w-[60px] text-center">{quantity}</span>
                <button onClick={() => setQuantity(q => q + 1)} className="p-3 hover:bg-gray-200 rounded-r-xl transition">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Add to Cart */}
            <div className="flex gap-3 mb-6">
              <button
                onClick={handleAddToCart}
                disabled={(hasVariants && !selectedOption) || !inStock}
                className={`flex-1 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${
                  addedToCart
                    ? 'bg-green-600 text-white'
                    : 'bg-[#F97316] text-white hover:bg-orange-600 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-orange-500/30'
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                {!inStock ? 'Out of Stock' : hasVariants && !selectedOption ? 'Select an Option' : addedToCart ? 'Added to Cart!' : `Add to Cart - ${formatPrice(currentPrice * quantity)}`}
              </button>
            </div>

            {/* Trust */}
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Truck className="w-4 h-4 text-green-600" />
                Free Shipping
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <ShieldCheck className="w-4 h-4 text-blue-600" />
                Secure Payment
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MessageCircle className="w-4 h-4 text-purple-600" />
                Chat with Seller
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4 text-[#F97316]" />
                Local Delivery
              </div>
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">You May Also Like</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {relatedProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
