import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { formatPrice, MARKET_META } from '@/lib/constants';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import {
  BarChart3, Users, Store, Package, ShoppingCart, DollarSign, TrendingUp,
  MapPin, Settings, Shield, Eye, Ban, CheckCircle, AlertTriangle,
  ChevronRight, Plus, Edit, Trash2, Image
} from 'lucide-react';

export default function AdminDashboard() {
  const { user, isAuthenticated, setShowAuthModal, setAuthMode } = useAuth();
  const [activeTab, setActiveTab] = useState('analytics');
  const [collections, setCollections] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const [colRes, prodRes, ordRes] = await Promise.all([
        supabase.from('ecom_collections').select('*').order('created_at'),
        supabase.from('ecom_products').select('*').order('created_at', { ascending: false }),
        supabase.from('ecom_orders').select('*, items:ecom_order_items(*)').order('created_at', { ascending: false }).limit(50),
      ]);
      if (colRes.data) setCollections(colRes.data);
      if (prodRes.data) setProducts(prodRes.data);
      if (ordRes.data) setOrders(ordRes.data);
      setLoading(false);
    };
    fetchData();
  }, []);

  if (!isAuthenticated || user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-[#F9FAFB]">
        <Header /><AuthModal /><CartDrawer />
        <div className="max-w-lg mx-auto px-4 py-16 text-center">
          <Shield className="w-20 h-20 text-gray-200 mx-auto mb-6" />
          <h1 className="text-2xl font-bold text-gray-900 mb-3">Admin Dashboard</h1>
          <p className="text-gray-500 mb-6">This area is restricted to administrators only.</p>
          <button
            onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
            className="px-8 py-3 bg-[#1E3A8A] text-white rounded-xl font-bold hover:bg-blue-800 transition"
          >
            Login as Admin
          </button>
          <p className="text-xs text-gray-400 mt-3">Tip: Use an email containing "admin" to get admin role</p>
        </div>
        <Footer />
      </div>
    );
  }

  const totalRevenue = orders.reduce((s, o) => s + (o.total || 0), 0);
  const paidOrders = orders.filter(o => o.status === 'paid');
  const totalShops = Object.values(MARKET_META).reduce((s, m) => s + m.shops, 0);
  const uniqueVendors = [...new Set(products.map(p => p.vendor).filter(Boolean))];

  const tabs = [
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'markets', label: 'Markets', icon: Store },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
    { id: 'sellers', label: 'Sellers', icon: Users },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 text-sm text-gray-500">
          <Link to="/" className="hover:text-[#1E3A8A]">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-gray-900 font-medium">Admin Dashboard</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0F172A] to-[#1E3A8A] rounded-2xl p-6 mb-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-5 h-5 text-[#F97316]" />
                <span className="text-sm text-blue-300">Administrator</span>
              </div>
              <h1 className="text-xl font-bold">Bargur Market Connect - Admin Panel</h1>
              <p className="text-blue-200 text-sm mt-1">Manage all 7 markets, {totalShops}+ shops, and {products.length} products</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white rounded-xl border p-1 mb-6 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition whitespace-nowrap ${
                activeTab === tab.id ? 'bg-[#1E3A8A] text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Analytics */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Total Revenue', value: formatPrice(totalRevenue), icon: DollarSign, color: 'text-green-600 bg-green-50', change: '+18%' },
                { label: 'Total Orders', value: orders.length.toString(), icon: ShoppingCart, color: 'text-blue-600 bg-blue-50', change: '+12%' },
                { label: 'Active Products', value: products.filter(p => p.status === 'active').length.toString(), icon: Package, color: 'text-purple-600 bg-purple-50', change: '+5' },
                { label: 'Active Sellers', value: uniqueVendors.length.toString(), icon: Users, color: 'text-orange-600 bg-orange-50', change: '+3' },
              ].map((stat, i) => (
                <div key={i} className="bg-white rounded-2xl border p-5">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center`}>
                      <stat.icon className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">{stat.change}</span>
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Markets Overview */}
            <div className="bg-white rounded-2xl border">
              <div className="p-5 border-b">
                <h3 className="font-bold">Market Performance</h3>
              </div>
              <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {collections.map(col => {
                  const meta = MARKET_META[col.handle] || { shops: 0 };
                  const marketProducts = products.filter(p => p.metadata?.market === col.title);
                  return (
                    <div key={col.id} className="border rounded-xl p-4 hover:shadow-md transition">
                      <div className="flex items-center gap-3 mb-3">
                        <img src={col.image_url || '/placeholder.svg'} alt={col.title} className="w-12 h-12 rounded-lg object-cover" />
                        <div>
                          <h4 className="font-semibold text-sm">{col.title}</h4>
                          <p className="text-xs text-gray-500">{meta.shops} shops</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-center">
                        <div className="bg-blue-50 rounded-lg p-2">
                          <p className="text-lg font-bold text-[#1E3A8A]">{marketProducts.length}</p>
                          <p className="text-[10px] text-gray-500">Products</p>
                        </div>
                        <div className="bg-green-50 rounded-lg p-2">
                          <p className="text-lg font-bold text-green-600">{meta.shops}</p>
                          <p className="text-[10px] text-gray-500">Shops</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Revenue Chart placeholder */}
            <div className="bg-white rounded-2xl border p-6">
              <h3 className="font-bold mb-4">Revenue Trend (Last 7 Days)</h3>
              <div className="flex items-end gap-2 h-40">
                {[65, 45, 80, 55, 90, 70, 95].map((h, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div
                      className="w-full bg-gradient-to-t from-[#1E3A8A] to-[#3B82F6] rounded-t-lg transition-all hover:opacity-80"
                      style={{ height: `${h}%` }}
                    />
                    <span className="text-[10px] text-gray-400">
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Markets */}
        {activeTab === 'markets' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">All Markets ({collections.length})</h3>
              <button className="flex items-center gap-2 px-4 py-2.5 bg-[#1E3A8A] text-white rounded-xl font-medium hover:bg-blue-800 transition text-sm">
                <Plus className="w-4 h-4" /> Add Market
              </button>
            </div>
            <div className="grid gap-4">
              {collections.map(col => {
                const meta = MARKET_META[col.handle] || { shops: 0, lat: 0, lng: 0 };
                return (
                  <div key={col.id} className="bg-white rounded-xl border p-5 flex items-center gap-4">
                    <img src={col.image_url || '/placeholder.svg'} alt={col.title} className="w-20 h-20 rounded-xl object-cover" />
                    <div className="flex-1">
                      <h4 className="font-bold">{col.title}</h4>
                      <p className="text-sm text-gray-500 mt-0.5">{col.description}</p>
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                        <span className="flex items-center gap-1"><Store className="w-3 h-3" /> {meta.shops} shops</span>
                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {meta.lat.toFixed(4)}, {meta.lng.toFixed(4)}</span>
                        <span className={`px-2 py-0.5 rounded-full font-medium ${col.is_visible ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                          {col.is_visible ? 'Visible' : 'Hidden'}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition"><Edit className="w-4 h-4 text-gray-400" /></button>
                      <button className="p-2 hover:bg-red-50 rounded-lg transition"><Trash2 className="w-4 h-4 text-red-400" /></button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Products */}
        {activeTab === 'products' && (
          <div className="bg-white rounded-2xl border overflow-hidden">
            <div className="p-5 border-b flex items-center justify-between">
              <h3 className="font-bold">All Products ({products.length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Product</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Vendor</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Category</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Price</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Status</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map(p => (
                    <tr key={p.id} className="border-t hover:bg-gray-50">
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          <img src={p.images?.[0] || '/placeholder.svg'} alt="" className="w-10 h-10 rounded-lg object-cover" />
                          <span className="font-medium truncate max-w-[200px]">{p.name}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-gray-500">{p.vendor}</td>
                      <td className="px-5 py-3 text-gray-500">{p.product_type}</td>
                      <td className="px-5 py-3 font-semibold">{formatPrice(p.price)}</td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                          p.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                        }`}>{p.status}</span>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex gap-1">
                          <button className="p-1.5 hover:bg-gray-100 rounded"><Eye className="w-3.5 h-3.5 text-gray-400" /></button>
                          <button className="p-1.5 hover:bg-gray-100 rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                          <button className="p-1.5 hover:bg-red-50 rounded"><Ban className="w-3.5 h-3.5 text-red-400" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Orders */}
        {activeTab === 'orders' && (
          <div className="bg-white rounded-2xl border overflow-hidden">
            <div className="p-5 border-b">
              <h3 className="font-bold">All Orders ({orders.length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Order ID</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Items</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Status</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Total</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map(order => (
                    <tr key={order.id} className="border-t hover:bg-gray-50">
                      <td className="px-5 py-3 font-mono text-xs">#{order.id.slice(0, 8).toUpperCase()}</td>
                      <td className="px-5 py-3">{order.items?.length || 0} items</td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                          order.status === 'paid' ? 'bg-green-100 text-green-700' :
                          order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                          'bg-yellow-100 text-yellow-700'
                        }`}>{order.status}</span>
                      </td>
                      <td className="px-5 py-3 font-semibold">{formatPrice(order.total)}</td>
                      <td className="px-5 py-3 text-gray-500">{new Date(order.created_at).toLocaleDateString('en-IN')}</td>
                    </tr>
                  ))}
                  {orders.length === 0 && (
                    <tr><td colSpan={5} className="px-5 py-8 text-center text-gray-400">No orders yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Sellers */}
        {activeTab === 'sellers' && (
          <div className="space-y-4">
            <h3 className="font-bold text-lg">Registered Sellers ({uniqueVendors.length})</h3>
            <div className="grid gap-3">
              {uniqueVendors.map((vendor, i) => {
                const vendorProducts = products.filter(p => p.vendor === vendor);
                const market = vendorProducts[0]?.metadata?.market || 'Unknown';
                return (
                  <div key={i} className="bg-white rounded-xl border p-4 flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#1E3A8A] to-[#F97316] rounded-xl flex items-center justify-center text-white font-bold">
                      {(vendor as string)[0]}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold">{vendor}</h4>
                      <div className="flex items-center gap-3 text-xs text-gray-500 mt-0.5">
                        <span>{vendorProducts.length} products</span>
                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {market}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium">Approved</span>
                      <button className="p-2 hover:bg-gray-100 rounded-lg transition"><Eye className="w-4 h-4 text-gray-400" /></button>
                      <button className="p-2 hover:bg-red-50 rounded-lg transition"><Ban className="w-4 h-4 text-red-400" /></button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Settings */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl border p-6">
              <h3 className="font-bold mb-4">Platform Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Platform Name</label>
                  <input type="text" defaultValue="Bargur Market Connect" className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Commission Rate (%)</label>
                  <input type="number" defaultValue="5" className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Support Email</label>
                  <input type="email" defaultValue="support@bargurmarket.com" className="w-full px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                </div>
                <button className="px-6 py-2.5 bg-[#1E3A8A] text-white rounded-xl font-medium hover:bg-blue-800 transition text-sm">
                  Save Settings
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl border p-6">
              <h3 className="font-bold mb-4">Banner Ads Management</h3>
              <div className="border-2 border-dashed rounded-xl p-8 text-center">
                <Image className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 text-sm">Upload banner images for the home page slider</p>
                <button className="mt-3 px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium hover:bg-gray-200 transition">
                  Upload Banner
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
