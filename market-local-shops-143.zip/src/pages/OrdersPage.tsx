import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { formatPrice } from '@/lib/constants';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import { Package, ChevronRight, ShoppingBag, CheckCircle, Truck, MapPin } from 'lucide-react';

export default function OrdersPage() {
  const { user, isAuthenticated, setShowAuthModal, setAuthMode } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      const { data } = await supabase
        .from('ecom_orders')
        .select('*, items:ecom_order_items(*)')
        .order('created_at', { ascending: false })
        .limit(20);
      if (data) setOrders(data);
      setLoading(false);
    };
    fetchOrders();
  }, []);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#F9FAFB]">
        <Header /><AuthModal /><CartDrawer />
        <div className="max-w-lg mx-auto px-4 py-16 text-center">
          <ShoppingBag className="w-20 h-20 text-gray-200 mx-auto mb-6" />
          <h1 className="text-2xl font-bold text-gray-900 mb-3">My Orders</h1>
          <p className="text-gray-500 mb-6">Login to view your order history</p>
          <button onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
            className="px-8 py-3 bg-[#1E3A8A] text-white rounded-xl font-bold hover:bg-blue-800 transition">
            Login
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'shipped': return <Truck className="w-4 h-4 text-blue-600" />;
      case 'delivered': return <MapPin className="w-4 h-4 text-purple-600" />;
      default: return <Package className="w-4 h-4 text-yellow-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 text-sm text-gray-500">
          <Link to="/" className="hover:text-[#1E3A8A]">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-gray-900 font-medium">My Orders</span>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">My Orders</h1>

        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl border p-6 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-1/3 mb-3" />
                <div className="h-3 bg-gray-200 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border">
            <ShoppingBag className="w-16 h-16 text-gray-200 mx-auto mb-4" />
            <h2 className="text-lg font-bold text-gray-700">No orders yet</h2>
            <p className="text-gray-500 text-sm mt-1">Start shopping to see your orders here</p>
            <Link to="/products" className="mt-4 inline-block px-6 py-2.5 bg-[#1E3A8A] text-white rounded-xl font-medium hover:bg-blue-800 transition text-sm">
              Browse Products
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="bg-white rounded-2xl border overflow-hidden">
                <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(order.status)}
                    <div>
                      <p className="font-mono text-xs text-gray-500">#{order.id.slice(0, 8).toUpperCase()}</p>
                      <p className="text-xs text-gray-400">{new Date(order.created_at).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                      order.status === 'paid' ? 'bg-green-100 text-green-700' :
                      order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                      order.status === 'delivered' ? 'bg-purple-100 text-purple-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>{order.status?.charAt(0).toUpperCase() + order.status?.slice(1)}</span>
                  </div>
                </div>
                <div className="p-4">
                  {order.items?.map((item: any) => (
                    <div key={item.id} className="flex items-center justify-between py-2">
                      <div>
                        <p className="text-sm font-medium">{item.product_name}</p>
                        {item.variant_title && <p className="text-xs text-gray-500">{item.variant_title}</p>}
                        <p className="text-xs text-gray-400">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-semibold text-sm">{formatPrice(item.total)}</p>
                    </div>
                  ))}
                  <div className="border-t mt-2 pt-2 flex justify-between">
                    <span className="font-medium text-sm text-gray-600">Total</span>
                    <span className="font-bold text-[#1E3A8A]">{formatPrice(order.total)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
