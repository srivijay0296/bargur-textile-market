import { Link } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/lib/constants';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft, Truck, ChevronRight } from 'lucide-react';

export default function CartPage() {
  const { cart, removeFromCart, updateQuantity, cartTotal, clearCart } = useCart();

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 text-sm text-gray-500">
          <Link to="/" className="hover:text-[#1E3A8A]">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-gray-900 font-medium">Shopping Cart</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Shopping Cart ({cart.length} items)</h1>

        {cart.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border">
            <ShoppingBag className="w-20 h-20 text-gray-200 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-700 mb-2">Your cart is empty</h2>
            <p className="text-gray-500 mb-6">Browse our markets and add products to your cart</p>
            <Link to="/products" className="inline-flex items-center gap-2 px-6 py-3 bg-[#1E3A8A] text-white rounded-xl font-semibold hover:bg-blue-800 transition">
              <ArrowLeft className="w-4 h-4" /> Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Items */}
            <div className="lg:col-span-2 space-y-4">
              {cart.map(item => (
                <div key={item.product_id + (item.variant_id || '')} className="bg-white rounded-2xl border p-4 flex gap-4">
                  <img src={item.image || '/placeholder.svg'} alt={item.name} className="w-24 h-24 sm:w-32 sm:h-32 object-cover rounded-xl" />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900">{item.name}</h3>
                    {item.variant_title && <p className="text-sm text-gray-500">{item.variant_title}</p>}
                    {item.vendor && <p className="text-xs text-gray-400 mt-0.5">{item.vendor}</p>}
                    <p className="text-lg font-bold text-[#1E3A8A] mt-2">{formatPrice(item.price)}</p>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-1 bg-gray-100 rounded-xl">
                        <button onClick={() => updateQuantity(item.product_id, item.variant_id, item.quantity - 1)} className="p-2 hover:bg-gray-200 rounded-l-xl transition">
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="px-4 font-semibold">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.product_id, item.variant_id, item.quantity + 1)} className="p-2 hover:bg-gray-200 rounded-r-xl transition">
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-bold text-gray-900">{formatPrice(item.price * item.quantity)}</span>
                        <button onClick={() => removeFromCart(item.product_id, item.variant_id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between">
                <Link to="/products" className="flex items-center gap-2 text-[#1E3A8A] font-medium hover:underline text-sm">
                  <ArrowLeft className="w-4 h-4" /> Continue Shopping
                </Link>
                <button onClick={clearCart} className="text-red-500 text-sm font-medium hover:underline">Clear Cart</button>
              </div>
            </div>

            {/* Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl border p-6 sticky top-20">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Order Summary</h3>
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal ({cart.reduce((s, i) => s + i.quantity, 0)} items)</span>
                    <span className="font-medium">{formatPrice(cartTotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Shipping</span>
                    <span className="text-green-600 font-medium flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5" /> Free
                    </span>
                  </div>
                  <div className="border-t pt-3 flex justify-between">
                    <span className="font-bold text-gray-900">Total</span>
                    <span className="text-xl font-bold text-[#1E3A8A]">{formatPrice(cartTotal)}</span>
                  </div>
                </div>
                <Link
                  to="/checkout"
                  className="block w-full py-3.5 bg-[#F97316] text-white rounded-xl font-bold text-center hover:bg-orange-600 transition shadow-lg shadow-orange-500/30"
                >
                  Proceed to Checkout
                </Link>
                <p className="text-xs text-gray-400 text-center mt-3">Secure checkout powered by Stripe</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
