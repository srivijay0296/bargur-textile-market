import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { formatPrice } from '@/lib/constants';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import {
  Store, Package, ShoppingCart, TrendingUp, Plus, Eye, Edit, ToggleLeft, ToggleRight,
  Upload, Camera, DollarSign, BarChart3, MessageCircle, Bell, ChevronRight
} from 'lucide-react';

export default function SellerDashboard() {
  const { user, isAuthenticated, setShowAuthModal, setAuthMode } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '', description: '', price: '', stock: '', category: '', market: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      const { data: prods } = await supabase
        .from('ecom_products')
        .select('*, variants:ecom_product_variants(*)')
        .eq('status', 'active')
        .order('created_at', { ascending: false });
      if (prods) setProducts(prods);

      const { data: ords } = await supabase
        .from('ecom_orders')
        .select('*, items:ecom_order_items(*)')
        .order('created_at', { ascending: false })
        .limit(20);
      if (ords) setOrders(ords);
      setLoading(false);
    };
    fetchData();
  }, []);

  if (!isAuthenticated || (user?.role !== 'seller' && user?.role !== 'admin')) {
    return (
      <div className="min-h-screen bg-[#F9FAFB]">
        <Header /><AuthModal /><CartDrawer />
        <div className="max-w-lg mx-auto px-4 py-16 text-center">
          <Store className="w-20 h-20 text-gray-200 mx-auto mb-6" />
          <h1 className="text-2xl font-bold text-gray-900 mb-3">Seller Dashboard</h1>
          <p className="text-gray-500 mb-6">Login as a seller to manage your shop, products, and orders on Bargur Market Connect.</p>
          <button
            onClick={() => { setAuthMode('signup'); setShowAuthModal(true); }}
            className="px-8 py-3 bg-[#F97316] text-white rounded-xl font-bold hover:bg-orange-600 transition"
          >
            Register as Seller
          </button>
          <p className="text-sm text-gray-400 mt-4">
            Already have an account?{' '}
            <button onClick={() => { setAuthMode('login'); setShowAuthModal(true); }} className="text-[#1E3A8A] font-medium hover:underline">
              Login here
            </button>
          </p>
        </div>
        <Footer />
      </div>
    );
  }

  const totalRevenue = orders.reduce((s, o) => s + (o.total || 0), 0);
  const totalOrders = orders.length;
  const totalProducts = products.length;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
    { id: 'messages', label: 'Messages', icon: MessageCircle },
  ];

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 text-sm text-gray-500">
          <Link to="/" className="hover:text-[#1E3A8A]">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-gray-900 font-medium">Seller Dashboard</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Welcome */}
        <div className="bg-gradient-to-r from-[#1E3A8A] to-[#2563EB] rounded-2xl p-6 mb-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold">Welcome, {user?.name}!</h1>
              <p className="text-blue-200 text-sm mt-1">Manage your shop on Bargur Market Connect</p>
            </div>
            <div className="flex gap-2">
              <button className="p-2 bg-white/20 rounded-xl hover:bg-white/30 transition">
                <Bell className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white rounded-xl border p-1 mb-6 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition whitespace-nowrap ${
                activeTab === tab.id ? 'bg-[#1E3A8A] text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Overview */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Total Revenue', value: formatPrice(totalRevenue), icon: DollarSign, color: 'text-green-600 bg-green-50' },
                { label: 'Total Orders', value: totalOrders.toString(), icon: ShoppingCart, color: 'text-blue-600 bg-blue-50' },
                { label: 'Products', value: totalProducts.toString(), icon: Package, color: 'text-purple-600 bg-purple-50' },
                { label: 'Growth', value: '+12%', icon: TrendingUp, color: 'text-orange-600 bg-orange-50' },
              ].map((stat, i) => (
                <div key={i} className="bg-white rounded-2xl border p-5">
                  <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
                    <stat.icon className="w-5 h-5" />
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Recent Orders */}
            <div className="bg-white rounded-2xl border">
              <div className="p-5 border-b flex items-center justify-between">
                <h3 className="font-bold">Recent Orders</h3>
                <button onClick={() => setActiveTab('orders')} className="text-sm text-[#1E3A8A] hover:underline">View All</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left px-5 py-3 font-medium text-gray-500">Order ID</th>
                      <th className="text-left px-5 py-3 font-medium text-gray-500">Status</th>
                      <th className="text-left px-5 py-3 font-medium text-gray-500">Total</th>
                      <th className="text-left px-5 py-3 font-medium text-gray-500">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.slice(0, 5).map(order => (
                      <tr key={order.id} className="border-t hover:bg-gray-50">
                        <td className="px-5 py-3 font-mono text-xs">#{order.id.slice(0, 8).toUpperCase()}</td>
                        <td className="px-5 py-3">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                            order.status === 'paid' ? 'bg-green-100 text-green-700' :
                            order.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-gray-100 text-gray-700'
                          }`}>{order.status}</span>
                        </td>
                        <td className="px-5 py-3 font-semibold">{formatPrice(order.total)}</td>
                        <td className="px-5 py-3 text-gray-500">{new Date(order.created_at).toLocaleDateString('en-IN')}</td>
                      </tr>
                    ))}
                    {orders.length === 0 && (
                      <tr><td colSpan={4} className="px-5 py-8 text-center text-gray-400">No orders yet</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Products */}
        {activeTab === 'products' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg">My Products ({products.length})</h3>
              <button
                onClick={() => setShowAddProduct(!showAddProduct)}
                className="flex items-center gap-2 px-4 py-2.5 bg-[#F97316] text-white rounded-xl font-medium hover:bg-orange-600 transition text-sm"
              >
                <Plus className="w-4 h-4" /> Add Product
              </button>
            </div>

            {showAddProduct && (
              <div className="bg-white rounded-2xl border p-6">
                <h4 className="font-bold mb-4">Add New Product</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <input placeholder="Product Name" value={newProduct.name} onChange={e => setNewProduct({ ...newProduct, name: e.target.value })}
                    className="px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  <input placeholder="Category" value={newProduct.category} onChange={e => setNewProduct({ ...newProduct, category: e.target.value })}
                    className="px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  <input placeholder="Price (₹)" type="number" value={newProduct.price} onChange={e => setNewProduct({ ...newProduct, price: e.target.value })}
                    className="px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  <input placeholder="Stock Quantity" type="number" value={newProduct.stock} onChange={e => setNewProduct({ ...newProduct, stock: e.target.value })}
                    className="px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
                  <textarea placeholder="Description" value={newProduct.description} onChange={e => setNewProduct({ ...newProduct, description: e.target.value })}
                    className="sm:col-span-2 px-4 py-2.5 border-2 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" rows={3} />
                </div>
                <div className="mt-4 flex items-center gap-4">
                  <button className="flex items-center gap-2 px-4 py-2.5 border-2 border-dashed rounded-xl text-sm text-gray-500 hover:border-[#1E3A8A] hover:text-[#1E3A8A] transition">
                    <Camera className="w-4 h-4" /> Upload Images
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2.5 border-2 border-dashed rounded-xl text-sm text-gray-500 hover:border-[#1E3A8A] hover:text-[#1E3A8A] transition">
                    <Upload className="w-4 h-4" /> Upload Video
                  </button>
                </div>
                <div className="mt-4 flex gap-3">
                  <button className="px-6 py-2.5 bg-[#1E3A8A] text-white rounded-xl font-medium hover:bg-blue-800 transition text-sm">
                    Save Product
                  </button>
                  <button onClick={() => setShowAddProduct(false)} className="px-6 py-2.5 bg-gray-100 text-gray-700 rounded-xl font-medium hover:bg-gray-200 transition text-sm">
                    Cancel
                  </button>
                </div>
              </div>
            )}

            <div className="grid gap-3">
              {products.map(p => (
                <div key={p.id} className="bg-white rounded-xl border p-4 flex items-center gap-4">
                  <img src={p.images?.[0] || '/placeholder.svg'} alt={p.name} className="w-16 h-16 object-cover rounded-lg" />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm truncate">{p.name}</h4>
                    <p className="text-xs text-gray-500">{p.product_type} | {p.vendor}</p>
                    <p className="font-bold text-[#1E3A8A] text-sm mt-1">{formatPrice(p.price)}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                      (p.inventory_qty == null || p.inventory_qty > 0) ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {(p.inventory_qty == null || p.inventory_qty > 0) ? 'Active' : 'Out of Stock'}
                    </span>
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition"><Eye className="w-4 h-4 text-gray-400" /></button>
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition"><Edit className="w-4 h-4 text-gray-400" /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Orders */}
        {activeTab === 'orders' && (
          <div className="bg-white rounded-2xl border overflow-hidden">
            <div className="p-5 border-b">
              <h3 className="font-bold">All Orders</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Order ID</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Items</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Status</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Total</th>
                    <th className="text-left px-5 py-3 font-medium text-gray-500">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map(order => (
                    <tr key={order.id} className="border-t hover:bg-gray-50">
                      <td className="px-5 py-3 font-mono text-xs">#{order.id.slice(0, 8).toUpperCase()}</td>
                      <td className="px-5 py-3">{order.items?.length || 0} items</td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                          order.status === 'paid' ? 'bg-green-100 text-green-700' :
                          order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                          order.status === 'delivered' ? 'bg-purple-100 text-purple-700' :
                          'bg-yellow-100 text-yellow-700'
                        }`}>{order.status}</span>
                      </td>
                      <td className="px-5 py-3 font-semibold">{formatPrice(order.total)}</td>
                      <td className="px-5 py-3 text-gray-500">{new Date(order.created_at).toLocaleDateString('en-IN')}</td>
                    </tr>
                  ))}
                  {orders.length === 0 && (
                    <tr><td colSpan={5} className="px-5 py-8 text-center text-gray-400">No orders yet</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Messages */}
        {activeTab === 'messages' && (
          <div className="bg-white rounded-2xl border p-8 text-center">
            <MessageCircle className="w-16 h-16 text-gray-200 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-gray-700">No messages yet</h3>
            <p className="text-gray-500 text-sm mt-1">Buyer messages will appear here when they contact you</p>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
