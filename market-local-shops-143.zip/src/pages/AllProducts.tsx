import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';
import CartDrawer from '@/components/CartDrawer';
import ProductCard from '@/components/ProductCard';
import { Search, Filter, X, ChevronRight, Package } from 'lucide-react';

export default function AllProducts() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<any[]>([]);
  const [filtered, setFiltered] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('default');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || '');
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');
  const [priceMax, setPriceMax] = useState(100000);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      const { data } = await supabase
        .from('ecom_products')
        .select('*, variants:ecom_product_variants(*)')
        .eq('status', 'active')
        .order('created_at', { ascending: false });
      if (data) setProducts(data);
      setLoading(false);
    };
    fetchProducts();
  }, []);

  useEffect(() => {
    setSelectedCategory(searchParams.get('category') || '');
    setSearchQuery(searchParams.get('search') || '');
  }, [searchParams]);

  useEffect(() => {
    let result = [...products];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description?.toLowerCase().includes(q) ||
        p.vendor?.toLowerCase().includes(q) ||
        p.product_type?.toLowerCase().includes(q)
      );
    }

    if (selectedCategory) {
      result = result.filter(p => p.product_type === selectedCategory);
    }

    result = result.filter(p => {
      const price = p.variants?.length > 0 ? Math.min(...p.variants.map((v: any) => v.price)) : p.price;
      return price <= priceMax;
    });

    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => {
          const pa = a.variants?.length > 0 ? Math.min(...a.variants.map((v: any) => v.price)) : a.price;
          const pb = b.variants?.length > 0 ? Math.min(...b.variants.map((v: any) => v.price)) : b.price;
          return pa - pb;
        });
        break;
      case 'price-desc':
        result.sort((a, b) => {
          const pa = a.variants?.length > 0 ? Math.min(...a.variants.map((v: any) => v.price)) : a.price;
          const pb = b.variants?.length > 0 ? Math.min(...b.variants.map((v: any) => v.price)) : b.price;
          return pb - pa;
        });
        break;
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }

    setFiltered(result);
  }, [products, searchQuery, selectedCategory, sortBy, priceMax]);

  const categories = [...new Set(products.map(p => p.product_type).filter(Boolean))];
  const vendors = [...new Set(products.map(p => p.vendor).filter(Boolean))];

  const clearFilters = () => {
    setSelectedCategory('');
    setSearchQuery('');
    setSortBy('default');
    setPriceMax(100000);
    setSearchParams({});
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-2 text-sm text-gray-500">
          <Link to="/" className="hover:text-[#1E3A8A]">Home</Link>
          <ChevronRight className="w-3.5 h-3.5" />
          <span className="text-gray-900 font-medium">All Products</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <aside className="lg:w-64 shrink-0">
            <div className="bg-white rounded-2xl p-5 border sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-900 flex items-center gap-2">
                  <Filter className="w-4 h-4" /> Filters
                </h3>
                {(selectedCategory || searchQuery) && (
                  <button onClick={clearFilters} className="text-xs text-red-500 hover:underline">Clear all</button>
                )}
              </div>

              {/* Search */}
              <div className="mb-5">
                <div className="relative">
                  <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search..."
                    className="w-full pl-9 pr-4 py-2 border rounded-lg text-sm focus:outline-none focus:border-[#1E3A8A]"
                  />
                </div>
              </div>

              {/* Categories */}
              <div className="mb-5">
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Category</h4>
                <div className="space-y-1">
                  <button
                    onClick={() => setSelectedCategory('')}
                    className={`block w-full text-left px-3 py-1.5 rounded-lg text-sm transition ${!selectedCategory ? 'bg-[#1E3A8A] text-white' : 'hover:bg-gray-50 text-gray-600'}`}
                  >
                    All Categories
                  </button>
                  {categories.map(c => (
                    <button
                      key={c}
                      onClick={() => setSelectedCategory(c)}
                      className={`block w-full text-left px-3 py-1.5 rounded-lg text-sm transition ${selectedCategory === c ? 'bg-[#1E3A8A] text-white' : 'hover:bg-gray-50 text-gray-600'}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price */}
              <div className="mb-5">
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Max Price</h4>
                <input
                  type="range"
                  min={0}
                  max={100000}
                  step={1000}
                  value={priceMax}
                  onChange={e => setPriceMax(Number(e.target.value))}
                  className="w-full accent-[#1E3A8A]"
                />
                <p className="text-sm text-gray-500 mt-1">Up to ₹{(priceMax / 100).toFixed(0)}</p>
              </div>

              {/* Shops */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-2">Shops</h4>
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {vendors.map(v => (
                    <button
                      key={v}
                      onClick={() => setSearchQuery(v)}
                      className="block w-full text-left px-3 py-1.5 rounded-lg text-sm hover:bg-gray-50 text-gray-600 transition truncate"
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Products */}
          <main className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <p className="text-sm text-gray-600">
                <span className="font-semibold">{filtered.length}</span> products
                {searchQuery && <> for "<span className="font-medium">{searchQuery}</span>"</>}
              </p>
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value)}
                className="text-sm border rounded-lg px-3 py-2 focus:outline-none focus:border-[#1E3A8A]"
              >
                <option value="default">Sort by: Default</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="name">Name: A-Z</option>
              </select>
            </div>

            {loading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-2xl overflow-hidden animate-pulse">
                    <div className="aspect-square bg-gray-200" />
                    <div className="p-4 space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-3/4" />
                      <div className="h-5 bg-gray-200 rounded w-1/3" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-16">
                <Package className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-700">No products found</h3>
                <p className="text-gray-500 text-sm mt-1">Try adjusting your filters</p>
                <button onClick={clearFilters} className="mt-4 text-[#1E3A8A] font-medium hover:underline">Clear all filters</button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {filtered.map(p => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      <Footer />
    </div>
  );
}
