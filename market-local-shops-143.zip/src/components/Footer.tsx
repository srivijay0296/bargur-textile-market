import { Link } from 'react-router-dom';
import { Store, MapPin, Phone, Mail, Facebook, Instagram, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#0F172A] text-gray-300">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E3A8A] to-[#F97316] rounded-xl flex items-center justify-center">
                <Store className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold">Bargur Market</h3>
                <p className="text-[10px] text-gray-400">CONNECT</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              Your hyperlocal marketplace connecting buyers and sellers across 7 vibrant markets in Bargur, Krishnagiri District, Tamil Nadu.
            </p>
            <div className="flex items-center gap-1.5 text-sm text-gray-400">
              <MapPin className="w-4 h-4 text-[#F97316]" />
              Bargur, Krishnagiri, Tamil Nadu, India
            </div>
          </div>

          {/* Markets */}
          <div>
            <h4 className="text-white font-semibold mb-4">Our Markets</h4>
            <ul className="space-y-2 text-sm">
              {['A1 Market', 'Mahalakshmi Market', 'Kalignar Market', 'Surat Market', 'Ayyapa Market', 'BT Market', 'ABC Market'].map(m => (
                <li key={m}>
                  <Link to={`/collections/${m.toLowerCase().replace(/\s+/g, '-')}`} className="hover:text-[#F97316] transition">
                    {m}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/products" className="hover:text-[#F97316] transition">All Products</Link></li>
              <li><Link to="/seller-dashboard" className="hover:text-[#F97316] transition">Become a Seller</Link></li>
              <li><Link to="/admin" className="hover:text-[#F97316] transition">Admin Panel</Link></li>
              <li><Link to="/cart" className="hover:text-[#F97316] transition">My Cart</Link></li>
              <li><Link to="/orders" className="hover:text-[#F97316] transition">Track Orders</Link></li>
              <li><a href="#" className="hover:text-[#F97316] transition">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-[#F97316] transition">Terms of Service</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#F97316]" />
                +91 98765 43210
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#F97316]" />
                support@bargurmarket.com
              </li>
            </ul>
            <div className="mt-6">
              <h5 className="text-white text-sm font-semibold mb-3">Follow Us</h5>
              <div className="flex gap-3">
                {[Facebook, Instagram, Twitter].map((Icon, i) => (
                  <a key={i} href="#" className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-[#F97316] transition">
                    <Icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500">
          <p>2026 Bargur Market Connect. All rights reserved.</p>
          <p>Made with care for the people of Bargur</p>
        </div>
      </div>
    </footer>
  );
}
