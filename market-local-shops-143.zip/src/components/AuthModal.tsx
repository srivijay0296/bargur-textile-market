import { useState } from 'react';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import { X, Phone, Mail, Lock, User, Store } from 'lucide-react';

export default function AuthModal() {
  const { showAuthModal, setShowAuthModal, authMode, setAuthMode, login, signup, loginWithOTP, verifyOTP, isLoading } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');
  const [otpSent, setOtpSent] = useState(false);
  const [error, setError] = useState('');

  if (!showAuthModal) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await login(email, password);
    } catch (err: any) {
      setError(err.message || 'Login failed');
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await signup({ name, email, password, role, phone });
    } catch (err: any) {
      setError(err.message || 'Signup failed');
    }
  };

  const handleSendOTP = async () => {
    if (!phone || phone.length < 10) {
      setError('Enter a valid phone number');
      return;
    }
    setError('');
    await loginWithOTP(phone);
    setOtpSent(true);
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await verifyOTP(phone, otp);
    } catch (err: any) {
      setError(err.message || 'OTP verification failed');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setShowAuthModal(false)} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#1E3A8A] to-[#2563EB] p-6 text-white">
          <button onClick={() => setShowAuthModal(false)} className="absolute top-4 right-4 p-1 rounded-lg hover:bg-white/20 transition">
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 mb-2">
            <Store className="w-6 h-6" />
            <span className="font-bold">Bargur Market Connect</span>
          </div>
          <h2 className="text-xl font-bold">
            {authMode === 'login' ? 'Welcome Back!' : authMode === 'signup' ? 'Create Account' : 'OTP Login'}
          </h2>
          <p className="text-blue-200 text-sm mt-1">
            {authMode === 'login' ? 'Sign in to continue shopping' : authMode === 'signup' ? 'Join the Bargur marketplace' : 'Quick login with your phone'}
          </p>
        </div>

        {/* Mode tabs */}
        <div className="flex border-b">
          {(['login', 'signup', 'otp'] as const).map(mode => (
            <button
              key={mode}
              onClick={() => { setAuthMode(mode); setError(''); setOtpSent(false); }}
              className={`flex-1 py-3 text-sm font-medium transition ${authMode === mode ? 'text-[#1E3A8A] border-b-2 border-[#1E3A8A]' : 'text-gray-500 hover:text-gray-700'}`}
            >
              {mode === 'login' ? 'Login' : mode === 'signup' ? 'Sign Up' : 'OTP'}
            </button>
          ))}
        </div>

        {/* Forms */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">{error}</div>
          )}

          {authMode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email address" required
                  className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" required
                  className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
              </div>
              <p className="text-xs text-gray-500">Tip: Use "admin@" for admin, "seller@" for seller role</p>
              <button type="submit" disabled={isLoading}
                className="w-full py-3 bg-[#1E3A8A] text-white rounded-xl font-semibold hover:bg-blue-800 transition disabled:opacity-50">
                {isLoading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>
          )}

          {authMode === 'signup' && (
            <form onSubmit={handleSignup} className="space-y-4">
              <div className="relative">
                <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Full name" required
                  className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
              </div>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email address" required
                  className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
              </div>
              <div className="relative">
                <Phone className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="Phone number"
                  className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" required
                  className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">I want to</label>
                <div className="grid grid-cols-2 gap-2">
                  {[{ v: 'buyer' as UserRole, l: 'Buy Products' }, { v: 'seller' as UserRole, l: 'Sell Products' }].map(r => (
                    <button key={r.v} type="button" onClick={() => setRole(r.v)}
                      className={`py-2.5 rounded-xl border-2 text-sm font-medium transition ${role === r.v ? 'border-[#1E3A8A] bg-blue-50 text-[#1E3A8A]' : 'border-gray-200 text-gray-600 hover:border-gray-300'}`}>
                      {r.l}
                    </button>
                  ))}
                </div>
              </div>
              <button type="submit" disabled={isLoading}
                className="w-full py-3 bg-[#F97316] text-white rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-50">
                {isLoading ? 'Creating account...' : 'Create Account'}
              </button>
            </form>
          )}

          {authMode === 'otp' && (
            <form onSubmit={handleVerifyOTP} className="space-y-4">
              <div className="relative">
                <Phone className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+91 Phone number" required
                  className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm" />
              </div>
              {!otpSent ? (
                <button type="button" onClick={handleSendOTP}
                  className="w-full py-3 bg-[#1E3A8A] text-white rounded-xl font-semibold hover:bg-blue-800 transition">
                  Send OTP
                </button>
              ) : (
                <>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <input type="text" value={otp} onChange={e => setOtp(e.target.value)} placeholder="Enter 6-digit OTP" maxLength={6} required
                      className="w-full pl-10 pr-4 py-2.5 border-2 border-gray-200 rounded-xl focus:border-[#1E3A8A] focus:outline-none text-sm tracking-widest text-center text-lg" />
                  </div>
                  <p className="text-xs text-gray-500 text-center">Enter any 6 digits to verify (demo)</p>
                  <button type="submit" disabled={isLoading}
                    className="w-full py-3 bg-[#F97316] text-white rounded-xl font-semibold hover:bg-orange-600 transition disabled:opacity-50">
                    {isLoading ? 'Verifying...' : 'Verify & Login'}
                  </button>
                </>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
