import { Link } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { ShoppingCart, MapPin, Tag } from 'lucide-react';
import { formatPrice } from '@/lib/constants';

interface ProductCardProps {
  product: any;
  compact?: boolean;
}

export default function ProductCard({ product, compact }: ProductCardProps) {
  const { addToCart } = useCart();

  const effectivePrice = product.variants?.length > 0
    ? Math.min(...product.variants.map((v: any) => v.price))
    : product.price;

  const hasMultiplePrices = product.variants?.length > 0 &&
    new Set(product.variants.map((v: any) => v.price)).size > 1;

  const inStock = product.has_variants
    ? product.variants?.some((v: any) => v.inventory_qty == null || v.inventory_qty > 0)
    : product.inventory_qty == null || product.inventory_qty > 0;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!inStock) return;

    const variant = product.variants?.length > 0
      ? product.variants.sort((a: any, b: any) => (a.position || 0) - (b.position || 0))[0]
      : null;

    addToCart({
      product_id: product.id,
      variant_id: variant?.id,
      name: product.name,
      variant_title: variant?.title,
      sku: variant?.sku || product.sku || product.handle,
      price: variant?.price || product.price,
      image: product.images?.[0],
      vendor: product.vendor,
    });
  };

  return (
    <Link
      to={`/product/${product.handle}`}
      className={`group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all duration-300 ${compact ? '' : ''}`}
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img
          src={product.images?.[0] || '/placeholder.svg'}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          loading="lazy"
        />
        {!inStock && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <span className="bg-white text-gray-800 px-3 py-1 rounded-full text-xs font-semibold">Out of Stock</span>
          </div>
        )}
        {product.tags?.includes('featured') && (
          <span className="absolute top-2 left-2 bg-[#F97316] text-white text-[10px] font-bold px-2 py-1 rounded-lg">
            FEATURED
          </span>
        )}
        {product.tags?.includes('trending') && (
          <span className="absolute top-2 left-2 bg-[#1E3A8A] text-white text-[10px] font-bold px-2 py-1 rounded-lg">
            TRENDING
          </span>
        )}
        {/* Quick add */}
        {inStock && (
          <button
            onClick={handleQuickAdd}
            className="absolute bottom-2 right-2 w-10 h-10 bg-white/90 backdrop-blur rounded-xl shadow-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-[#F97316] hover:text-white"
          >
            <ShoppingCart className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Info */}
      <div className="p-3 sm:p-4">
        {product.vendor && (
          <div className="flex items-center gap-1 mb-1">
            <MapPin className="w-3 h-3 text-[#F97316]" />
            <span className="text-[11px] text-gray-500 truncate">{product.vendor}</span>
          </div>
        )}
        <h3 className="font-semibold text-gray-900 text-sm sm:text-base line-clamp-2 mb-1 group-hover:text-[#1E3A8A] transition">
          {product.name}
        </h3>
        {product.product_type && (
          <div className="flex items-center gap-1 mb-2">
            <Tag className="w-3 h-3 text-gray-400" />
            <span className="text-[11px] text-gray-400">{product.product_type}</span>
          </div>
        )}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-lg font-bold text-[#1E3A8A]">
              {hasMultiplePrices ? 'From ' : ''}{formatPrice(effectivePrice)}
            </span>
            {product.metadata?.weight && (
              <span className="text-[11px] text-gray-400 ml-1">/ {product.metadata.weight}</span>
            )}
          </div>
          {inStock ? (
            <span className="text-[10px] font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">In Stock</span>
          ) : (
            <span className="text-[10px] font-medium text-red-600 bg-red-50 px-2 py-0.5 rounded-full">Sold Out</span>
          )}
        </div>
      </div>
    </Link>
  );
}
