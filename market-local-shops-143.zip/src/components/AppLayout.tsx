import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { HERO_IMAGES, MARKET_META, CATEGORIES, formatPrice } from '@/lib/constants';
import ProductCard from './ProductCard';
import Header from './Header';
import Footer from './Footer';
import AuthModal from './AuthModal';
import CartDrawer from './CartDrawer';
import { ChevronLeft, ChevronRight, MapPin, Store, TrendingUp, Sparkles, Clock, ArrowRight, ShieldCheck, Truck, Headphones } from 'lucide-react';

export default function AppLayout() {
  const [collections, setCollections] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<any[]>([]);
  const [trendingProducts, setTrendingProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      const [colRes, prodRes] = await Promise.all([
        supabase.from('ecom_collections').select('*').eq('is_visible', true).order('created_at'),
        supabase.from('ecom_products').select('*, variants:ecom_product_variants(*)').eq('status', 'active').order('created_at', { ascending: false }),
      ]);
      if (colRes.data) setCollections(colRes.data);
      if (prodRes.data) {
        setProducts(prodRes.data);
        setFeaturedProducts(prodRes.data.filter((p: any) => p.tags?.includes('featured')));
        setTrendingProducts(prodRes.data.filter((p: any) => p.tags?.includes('trending')));
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  // Auto-rotate hero
  useEffect(() => {
    const timer = setInterval(() => setHeroIndex(i => (i + 1) % HERO_IMAGES.length), 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-[#F9FAFB]">
      <Header />
      <AuthModal />
      <CartDrawer />

      {/* Hero Banner */}
      <section className="relative h-[320px] sm:h-[420px] lg:h-[500px] overflow-hidden">
        {HERO_IMAGES.map((img, i) => (
          <div
            key={i}
            className={`absolute inset-0 transition-opacity duration-1000 ${i === heroIndex ? 'opacity-100' : 'opacity-0'}`}
          >
            <img src={img} alt="Bargur Market" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
          </div>
        ))}
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-7xl mx-auto px-4 w-full">
            <div className="max-w-xl">
              <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur px-3 py-1.5 rounded-full text-white text-xs mb-4">
                <MapPin className="w-3.5 h-3.5" />
                Bargur, Krishnagiri District, Tamil Nadu
              </div>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight mb-3">
                Shop from <span className="text-[#F97316]">7 Local Markets</span> in Bargur
              </h1>
              <p className="text-gray-200 text-sm sm:text-base mb-6 max-w-md">
                Discover fresh produce, groceries, clothing & more from 285+ trusted local shops. Free delivery on all orders.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/products" className="px-6 py-3 bg-[#F97316] text-white rounded-xl font-semibold hover:bg-orange-600 transition shadow-lg shadow-orange-500/30">
                  Explore Products
                </Link>
                <Link to="/collections/a1-market" className="px-6 py-3 bg-white/20 backdrop-blur text-white rounded-xl font-semibold hover:bg-white/30 transition border border-white/30">
                  Browse Markets
                </Link>
              </div>
            </div>
          </div>
        </div>
        {/* Hero dots */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {HERO_IMAGES.map((_, i) => (
            <button key={i} onClick={() => setHeroIndex(i)}
              className={`w-2.5 h-2.5 rounded-full transition ${i === heroIndex ? 'bg-[#F97316] w-8' : 'bg-white/50'}`} />
          ))}
        </div>
        {/* Hero arrows */}
        <button onClick={() => setHeroIndex(i => (i - 1 + HERO_IMAGES.length) % HERO_IMAGES.length)}
          className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/20 backdrop-blur rounded-full flex items-center justify-center text-white hover:bg-white/30 transition hidden sm:flex">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button onClick={() => setHeroIndex(i => (i + 1) % HERO_IMAGES.length)}
          className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/20 backdrop-blur rounded-full flex items-center justify-center text-white hover:bg-white/30 transition hidden sm:flex">
          <ChevronRight className="w-5 h-5" />
        </button>
      </section>

      {/* Stats Bar */}
      <section className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { label: 'Markets', value: '7', icon: Store, color: 'text-[#1E3A8A]' },
            { label: 'Active Shops', value: '285+', icon: MapPin, color: 'text-[#F97316]' },
            { label: 'Products', value: '10,000+', icon: Sparkles, color: 'text-purple-600' },
            { label: 'Happy Buyers', value: '5,000+', icon: TrendingUp, color: 'text-green-600' },
          ].map((stat, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center ${stat.color}`}>
                <stat.icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-lg font-bold text-gray-900">{stat.value}</p>
                <p className="text-xs text-gray-500">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Browse by Market */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Browse by Market</h2>
            <p className="text-sm text-gray-500 mt-1">Explore all 7 markets in Bargur</p>
          </div>
          <Link to="/products" className="flex items-center gap-1 text-[#1E3A8A] text-sm font-medium hover:underline">
            View All <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {collections.map(col => {
            const meta = MARKET_META[col.handle] || { shops: 0 };
            return (
              <Link
                key={col.id}
                to={`/collections/${col.handle}`}
                className="group relative rounded-2xl overflow-hidden aspect-[4/3] hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <img src={col.image_url || '/placeholder.svg'} alt={col.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <h3 className="text-white font-bold text-sm sm:text-base">{col.title}</h3>
                  <div className="flex items-center gap-1.5 mt-1">
                    <Store className="w-3.5 h-3.5 text-[#F97316]" />
                    <span className="text-gray-300 text-xs">{meta.shops} Shops</span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Categories */}
      <section className="bg-white py-10">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Shop by Category</h2>
          <div className="grid grid-cols-4 sm:grid-cols-8 gap-3">
            {CATEGORIES.map(cat => (
              <Link
                key={cat.name}
                to={`/products?category=${encodeURIComponent(cat.name)}`}
                className="flex flex-col items-center gap-2 p-3 rounded-2xl hover:bg-gray-50 transition group"
              >
                <div className={`w-14 h-14 ${cat.color} rounded-2xl flex items-center justify-center text-sm font-bold group-hover:scale-110 transition-transform`}>
                  {cat.name.slice(0, 2)}
                </div>
                <span className="text-xs font-medium text-gray-700 text-center">{cat.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>


      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 py-10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-[#F97316]" />
              <h2 className="text-2xl font-bold text-gray-900">Featured Products</h2>
            </div>
            <Link to="/products" className="flex items-center gap-1 text-[#1E3A8A] text-sm font-medium hover:underline">
              View All <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {featuredProducts.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* Trending Products */}
      {trendingProducts.length > 0 && (
        <section className="bg-gradient-to-br from-[#1E3A8A] to-[#0F172A] py-10">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-[#F97316]" />
                <h2 className="text-2xl font-bold text-white">Trending Now</h2>
              </div>
              <Link to="/products" className="flex items-center gap-1 text-orange-300 text-sm font-medium hover:underline">
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {trendingProducts.map(p => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Recently Added */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Clock className="w-6 h-6 text-[#1E3A8A]" />
            <h2 className="text-2xl font-bold text-gray-900">Recently Added</h2>
          </div>
          <Link to="/products" className="flex items-center gap-1 text-[#1E3A8A] text-sm font-medium hover:underline">
            View All <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl overflow-hidden animate-pulse">
                <div className="aspect-square bg-gray-200" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                  <div className="h-3 bg-gray-200 rounded w-1/2" />
                  <div className="h-5 bg-gray-200 rounded w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.slice(0, 8).map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </section>

      {/* Trust Badges */}
      <section className="bg-white py-10 border-t">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { icon: Truck, title: 'Free Delivery', desc: 'Free shipping on all orders across Bargur', color: 'text-green-600 bg-green-50' },
              { icon: ShieldCheck, title: 'Secure Payments', desc: 'UPI, Cash on Delivery & Card payments accepted', color: 'text-blue-600 bg-blue-50' },
              { icon: Headphones, title: 'Local Support', desc: 'Dedicated support from Bargur-based team', color: 'text-purple-600 bg-purple-50' },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-4 p-6 rounded-2xl bg-gray-50">
                <div className={`w-14 h-14 rounded-2xl ${item.color} flex items-center justify-center shrink-0`}>
                  <item.icon className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{item.title}</h3>
                  <p className="text-sm text-gray-500 mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="bg-gradient-to-r from-[#F97316] to-[#EA580C] py-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">Start Selling on Bargur Market Connect</h2>
          <p className="text-orange-100 mb-6 max-w-lg mx-auto">
            Join 285+ local sellers and reach thousands of buyers in Bargur. Easy setup, zero listing fees.
          </p>
          <Link to="/seller-dashboard" className="inline-flex px-8 py-3.5 bg-white text-[#F97316] rounded-xl font-bold hover:bg-gray-100 transition shadow-lg">
            Register Your Shop
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
