import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';
import { Search, ShoppingCart, User, Menu, X, MapPin, ChevronDown, Store, LogOut, LayoutDashboard } from 'lucide-react';

export default function Header() {
  const { user, isAuthenticated, setShowAuthModal, setAuthMode, logout } = useAuth();
  const { cartCount, setIsCartOpen } = useCart();
  const [collections, setCollections] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [marketsOpen, setMarketsOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCollections = async () => {
      const { data } = await supabase
        .from('ecom_collections')
        .select('id, title, handle')
        .eq('is_visible', true)
        .order('created_at');
      if (data) setCollections(data);
    };
    fetchCollections();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      {/* Top bar */}
      <div className="bg-[#1E3A8A] text-white">
        <div className="max-w-7xl mx-auto px-4 py-1.5 flex items-center justify-between text-xs sm:text-sm">
          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" />
            <span>Bargur, Krishnagiri, Tamil Nadu, India</span>
          </div>
          <div className="hidden sm:flex items-center gap-4">
            <span>Free Shipping on All Orders</span>
            <span>|</span>
            <Link to="/seller-dashboard" className="hover:text-orange-300 transition">Sell on BMC</Link>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="w-10 h-10 bg-gradient-to-br from-[#1E3A8A] to-[#F97316] rounded-xl flex items-center justify-center">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-[#1E3A8A] leading-tight">Bargur Market</h1>
              <p className="text-[10px] text-gray-500 leading-tight -mt-0.5">CONNECT</p>
            </div>
          </Link>

          {/* Search */}
          <form onSubmit={handleSearch} className="flex-1 max-w-xl">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search products, shops, markets..."
                className="w-full pl-4 pr-12 py-2.5 rounded-xl border-2 border-gray-200 focus:border-[#1E3A8A] focus:outline-none transition text-sm"
              />
              <button type="submit" className="absolute right-1 top-1 bottom-1 px-3 bg-[#F97316] text-white rounded-lg hover:bg-orange-600 transition">
                <Search className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Cart */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-xl hover:bg-gray-100 transition"
            >
              <ShoppingCart className="w-5 h-5 text-gray-700" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#F97316] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* User */}
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 p-2 rounded-xl hover:bg-gray-100 transition"
                >
                  <div className="w-8 h-8 bg-[#1E3A8A] text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {user?.name?.[0]?.toUpperCase() || 'U'}
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-500 hidden sm:block" />
                </button>
                {userMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} />
                    <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl shadow-xl border z-50 py-2">
                      <div className="px-4 py-2 border-b">
                        <p className="font-semibold text-sm">{user?.name}</p>
                        <p className="text-xs text-gray-500">{user?.email}</p>
                        <span className="inline-block mt-1 px-2 py-0.5 bg-blue-100 text-blue-700 text-[10px] font-semibold rounded-full uppercase">
                          {user?.role}
                        </span>
                      </div>
                      {user?.role === 'seller' && (
                        <Link to="/seller-dashboard" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-gray-50 transition">
                          <LayoutDashboard className="w-4 h-4" /> Seller Dashboard
                        </Link>
                      )}
                      {user?.role === 'admin' && (
                        <Link to="/admin" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-gray-50 transition">
                          <LayoutDashboard className="w-4 h-4" /> Admin Dashboard
                        </Link>
                      )}
                      <Link to="/orders" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-gray-50 transition">
                        <ShoppingCart className="w-4 h-4" /> My Orders
                      </Link>
                      <button onClick={() => { logout(); setUserMenuOpen(false); }} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-gray-50 transition w-full text-left text-red-600">
                        <LogOut className="w-4 h-4" /> Logout
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <button
                onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
                className="flex items-center gap-1.5 px-4 py-2.5 bg-[#1E3A8A] text-white rounded-xl hover:bg-blue-800 transition text-sm font-medium"
              >
                <User className="w-4 h-4" />
                <span className="hidden sm:inline">Login</span>
              </button>
            )}

            {/* Mobile menu */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl hover:bg-gray-100 transition lg:hidden"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="hidden lg:block border-t bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <nav className="flex items-center gap-1">
            {/* Markets dropdown */}
            <div className="relative"
              onMouseEnter={() => setMarketsOpen(true)}
              onMouseLeave={() => setMarketsOpen(false)}
            >
              <button className="flex items-center gap-1.5 px-4 py-3 text-sm font-medium text-gray-700 hover:text-[#1E3A8A] transition">
                <Store className="w-4 h-4" />
                Browse Markets
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              {marketsOpen && (
                <div className="absolute left-0 top-full w-64 bg-white rounded-xl shadow-xl border z-50 py-2">
                  {collections.map(col => (
                    <Link
                      key={col.id}
                      to={`/collections/${col.handle}`}
                      onClick={() => setMarketsOpen(false)}
                      className="flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 transition"
                    >
                      <MapPin className="w-4 h-4 text-[#F97316]" />
                      <span className="text-sm">{col.title}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link to="/products" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-[#1E3A8A] transition">
              All Products
            </Link>
            {collections.slice(0, 5).map(col => (
              <Link
                key={col.id}
                to={`/collections/${col.handle}`}
                className="px-3 py-3 text-sm text-gray-600 hover:text-[#1E3A8A] transition"
              >
                {col.title}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t bg-white">
          <div className="max-w-7xl mx-auto px-4 py-4 space-y-2">
            <Link to="/products" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2.5 rounded-lg hover:bg-gray-50 text-sm font-medium">
              All Products
            </Link>
            <p className="px-4 pt-2 text-xs font-semibold text-gray-400 uppercase">Markets</p>
            {collections.map(col => (
              <Link
                key={col.id}
                to={`/collections/${col.handle}`}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg hover:bg-gray-50 text-sm"
              >
                <MapPin className="w-4 h-4 text-[#F97316]" />
                {col.title}
              </Link>
            ))}
            <div className="border-t pt-2">
              <Link to="/seller-dashboard" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-2.5 rounded-lg hover:bg-gray-50 text-sm font-medium text-[#F97316]">
                Sell on Bargur Market Connect
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
