export const HERO_IMAGES = [
  'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822191599_dcea3925.png',
  'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822285755_05f5cc59.jpg',
  'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822288358_1ae774a2.jpg',
];

export const MARKET_IMAGES: Record<string, string> = {
  'a1-market': 'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822217098_87aca72e.png',
  'mahalakshmi-market': 'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822234307_5b15348f.png',
  'kalignar-market': 'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822214021_555ef34e.jpg',
  'surat-market': 'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822214425_c860c85a.jpg',
  'ayyapa-market': 'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822215937_b64822df.jpg',
  'bt-market': 'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822223298_39603097.png',
  'abc-market': 'https://d64gsuwffb70l.cloudfront.net/699bdbf17b51ed955f62bf79_1771822217034_11973657.jpg',
};

export const MARKET_META: Record<string, { shops: number; lat: number; lng: number }> = {
  'a1-market': { shops: 45, lat: 12.2833, lng: 78.3667 },
  'mahalakshmi-market': { shops: 60, lat: 12.2845, lng: 78.3680 },
  'kalignar-market': { shops: 35, lat: 12.2820, lng: 78.3655 },
  'surat-market': { shops: 50, lat: 12.2850, lng: 78.3690 },
  'ayyapa-market': { shops: 30, lat: 12.2815, lng: 78.3645 },
  'bt-market': { shops: 40, lat: 12.2860, lng: 78.3700 },
  'abc-market': { shops: 25, lat: 12.2825, lng: 78.3660 },
};

export const CATEGORIES = [
  { name: 'Vegetables', icon: 'Leaf', color: 'bg-green-100 text-green-700' },
  { name: 'Fruits', icon: 'Apple', color: 'bg-yellow-100 text-yellow-700' },
  { name: 'Groceries', icon: 'ShoppingBasket', color: 'bg-blue-100 text-blue-700' },
  { name: 'Spices', icon: 'Flame', color: 'bg-red-100 text-red-700' },
  { name: 'Oils & Ghee', icon: 'Droplets', color: 'bg-amber-100 text-amber-700' },
  { name: 'Dairy & Eggs', icon: 'Milk', color: 'bg-purple-100 text-purple-700' },
  { name: 'Clothing', icon: 'Shirt', color: 'bg-pink-100 text-pink-700' },
  { name: 'Sweeteners', icon: 'Cookie', color: 'bg-orange-100 text-orange-700' },
];

export const SHIPPING_RULES = 'Free shipping on all orders';

export const STRIPE_ACCOUNT_ID = 'STRIPE_ACCOUNT_ID';

export const formatPrice = (cents: number) => {
  return '₹' + (cents / 100).toFixed(2);
};
