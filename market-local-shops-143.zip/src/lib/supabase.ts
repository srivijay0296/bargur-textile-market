import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://uvepscfdgbejdwpkzhqk.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjYwMGQzMzYxLTgwNmYtNDg1Zi1iMzk1LTZhZTg5MjBkZTliMiJ9.eyJwcm9qZWN0SWQiOiJ1dmVwc2NmZGdiZWpkd3BremhxayIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzcxODIyMDk2LCJleHAiOjIwODcxODIwOTYsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.AJOWD7NRBnWs_ej-UkU-uS85Zm-xL8tX_GoLcqgBzJY';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };