import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type UserRole = 'buyer' | 'seller' | 'admin' | 'market_manager';

interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  marketId?: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithOTP: (phone: string) => Promise<void>;
  verifyOTP: (phone: string, otp: string) => Promise<void>;
  signup: (data: { name: string; email: string; password: string; role: UserRole; phone?: string }) => Promise<void>;
  logout: () => void;
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  authMode: 'login' | 'signup' | 'otp';
  setAuthMode: (mode: 'login' | 'signup' | 'otp') => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'otp'>('login');

  useEffect(() => {
    const stored = localStorage.getItem('bmc_user');
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {}
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, _password: string) => {
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const newUser: User = {
      id: crypto.randomUUID(),
      name: email.split('@')[0],
      email,
      role: email.includes('admin') ? 'admin' : email.includes('seller') ? 'seller' : 'buyer',
    };
    setUser(newUser);
    localStorage.setItem('bmc_user', JSON.stringify(newUser));
    setShowAuthModal(false);
    setIsLoading(false);
  };

  const loginWithOTP = async (_phone: string) => {
    await new Promise(r => setTimeout(r, 500));
  };

  const verifyOTP = async (phone: string, _otp: string) => {
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const newUser: User = {
      id: crypto.randomUUID(),
      name: 'User ' + phone.slice(-4),
      email: phone + '@bargurmarket.com',
      phone,
      role: 'buyer',
    };
    setUser(newUser);
    localStorage.setItem('bmc_user', JSON.stringify(newUser));
    setShowAuthModal(false);
    setIsLoading(false);
  };

  const signup = async (data: { name: string; email: string; password: string; role: UserRole; phone?: string }) => {
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 800));
    const newUser: User = {
      id: crypto.randomUUID(),
      name: data.name,
      email: data.email,
      phone: data.phone,
      role: data.role,
    };
    setUser(newUser);
    localStorage.setItem('bmc_user', JSON.stringify(newUser));
    setShowAuthModal(false);
    setIsLoading(false);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('bmc_user');
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      loginWithOTP,
      verifyOTP,
      signup,
      logout,
      showAuthModal,
      setShowAuthModal,
      authMode,
      setAuthMode,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
